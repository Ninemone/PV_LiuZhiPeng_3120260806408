# -*- coding: utf-8 -*-
"""02_modeling.py -- 基线与机器学习模型（对应基础要求 3、4、5）

研究问题
--------
在已知当日气象观测（辐照度、环境温度、组件温度）与出力历史的前提下，
能够把光伏交流出力的预测误差压到多低？机器学习模型相对朴素基线能带来多少增益？

建模层级
--------
在**逆变器级**建模（每行 = 1 台逆变器 @ 1 时刻），再按时刻聚合成电站级指标。
这样做的原因见 01_eda.py：Plant_2 有 4 台逆变器长期离线，若直接在电站级求和，
预测目标会随时间出现与气象无关的台阶下降，模型会学到虚假的时间趋势。

防数据泄露
----------
* 训练/验证/测试按**日期**顺序切分（60/15/25），绝不随机打乱；
* 全部功率类特征先 shift(1) 再滚动，窗口内不含当前时刻功率；
* 归一化用的逆变器容量只由**训练集**估计。

产出
----
results/metrics_main.csv      主对比：基线 vs 各机器学习模型
results/metrics_plant.csv     电站级聚合后的指标
results/feature_ablation.csv  特征组消融
results/predictions.csv       最优模型的测试集逐点预测
results/logs/02_modeling.log  完整实验记录
"""
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import (RandomForestRegressor, HistGradientBoostingRegressor)
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
import lightgbm as lgb
import xgboost as xgb

from common import (log, banner, sub, prepare, split_by_day, metrics, save, save_df,
                    FEAT_WX_TIME, FEAT_WX_TIME_HIST, FEAT_NO_IRR_NOW, TARGET, LIT,
                    C_MAIN, C_ACC, C_BAD, C_GOOD, C_MUT, C2)

SEED = 42
PLANTS = (1, 2)

all_rows = []       # 主对比结果
abl_rows = []       # 消融结果
plant_rows = []     # 电站级结果
pred_store = {}     # plant -> 预测明细

with log("02_modeling"):

    # ================================================================ 模型库
    banner("模型定义")

    def make_models():
        """返回 {名称: 构造器}。"""
        m = {
            "线性回归(基线)": lambda: LinearRegression(),
            "随机森林": lambda: RandomForestRegressor(
                n_estimators=300, max_depth=None, min_samples_leaf=2,
                n_jobs=-1, random_state=SEED),
            "梯度提升树(HistGB)": lambda: HistGradientBoostingRegressor(
                max_iter=400, learning_rate=0.08, max_leaf_nodes=31,
                min_samples_leaf=20, l2_regularization=1.0, random_state=SEED),
            "LightGBM": lambda: lgb.LGBMRegressor(
                n_estimators=600, learning_rate=0.05, num_leaves=63,
                min_child_samples=20, subsample=0.9, subsample_freq=1,
                colsample_bytree=0.9, reg_lambda=1.0, random_state=SEED,
                n_jobs=-1, verbose=-1),
            "XGBoost": lambda: xgb.XGBRegressor(
                n_estimators=600, learning_rate=0.05, max_depth=7,
                subsample=0.9, colsample_bytree=0.9, reg_lambda=1.0,
                random_state=SEED, n_jobs=-1, tree_method="hist", verbosity=0),
            "多层感知机MLP": lambda max_iter=200: make_pipeline(
                StandardScaler(),
                MLPRegressor(hidden_layer_sizes=(256, 128, 64), activation="relu",
                             alpha=1e-3, batch_size=256, learning_rate_init=1e-3,
                             max_iter=max_iter, early_stopping=False,
                             random_state=SEED)),
        }
        return m

    # ================================================================ 基线
    def persistence_pred(d):
        """持续性基线：用同一台逆变器上一时刻（15 分钟前）的出力作为预测值。"""
        return d["ac_lag1"].values

    def clear_sky_pred(d, cap_map):
        """晴空物理基线：P = 额定出力 x 辐照度 x 组件温度降额。"""
        g = 1.0 + 0.004 * (d["T_MOD"].values - 25.0)
        cap = d["SOURCE_KEY"].map(cap_map).values
        ref = cap * np.clip(d["IRR"].values, 0, None) * g
        return np.where(d["IRR"].values <= LIT, 0.0, ref)

    def mean_pred(tr, te):
        """训练集均值基线。"""
        return np.full(len(te), tr[TARGET].mean())

    # ================================================================ 逐站实验
    for plant in PLANTS:
        banner(f"Plant_{plant}  实验")

        # ---------- 数据准备
        d_raw, n_inv, n_bad = prepare(plant, drop_daytime_zero=False)
        lit_raw = d_raw["IRR"] > LIT
        print(f"逆变器台数            : {n_inv}")
        print(f"原始样本              : {len(d_raw)} 条")
        print(f"有光时段读数为 0      : {n_bad} 条（有光样本的 {100 * n_bad / lit_raw.sum():.2f}%）"
              f" -> 判为通信/记录故障，剔除")
        d = d_raw[~((d_raw["IRR"] > LIT) & (d_raw["AC_POWER"] == 0))].copy()
        feat_all = FEAT_WX_TIME_HIST + ["inv_idx"]
        need = sorted(set(feat_all + [TARGET]))
        d = d.dropna(subset=need).reset_index(drop=True)
        print(f"清洗并剔除特征缺失后  : {len(d)} 条")

        tr, va, te, meta = split_by_day(d)
        print(f"按天切分              : 训练 {meta['train_days'][0]}~{meta['train_days'][1]} "
              f"({len(tr)} 条) | 验证 {meta['val_days'][0]}~{meta['val_days'][1]} "
              f"({len(va)} 条) | 测试 {meta['test_days'][0]}~{meta['test_days'][1]} ({len(te)} 条)")

        # 容量：仅由训练集估计
        cap_map = tr.groupby("SOURCE_KEY")[TARGET].quantile(0.99)
        cap_plant = float(cap_map.sum())
        mean_cap = float(cap_map.mean())
        print(f"单台逆变器容量(训练集99分位) : 均值 {mean_cap:.1f} kW，"
              f"范围 [{cap_map.min():.1f}, {cap_map.max():.1f}] kW")
        print(f"电站额定容量(22台合计)      : {cap_plant:.0f} kW")

        lit_tr = tr["IRR"] > LIT
        print(f"有光时段占比          : 训练 {100*lit_tr.mean():.1f}%，测试 {100*(te['IRR']>LIT).mean():.1f}%")
        print()

        def report(name, pred_te, extra=None, feats=None, secs=None):
            """算逆变器级 + 电站级指标并记录。secs = 训练耗时（秒），供报告溯源。"""
            y = te[TARGET].values
            lit = te["IRR"].values > LIT
            rec = dict(plant=plant, model=name, 特征组=extra or "全部特征", 样本数=len(te))
            rec["训练秒"] = (round(secs, 1) if secs is not None else None)
            m_all = metrics(y, pred_te, cap=mean_cap)
            m_lit = metrics(y[lit], pred_te[lit], cap=mean_cap)
            rec.update({f"{k}": round(v, 4) for k, v in m_all.items()})
            rec.update({f"有光{k}": round(v, 4) for k, v in m_lit.items()})
            all_rows.append(rec)

            # 电站级：按时刻聚合
            tmp = pd.DataFrame({"DATE_TIME": te["DATE_TIME"].values,
                                "SOURCE_KEY": te["SOURCE_KEY"].values,
                                "y": y, "p": pred_te})
            g = tmp.groupby("DATE_TIME").sum(numeric_only=True)
            pl_all = metrics(g["y"].values, g["p"].values, cap=cap_plant)
            pl_lit = metrics(g.loc[g.index.isin(te.loc[lit, "DATE_TIME"].unique()), "y"].values,
                             g.loc[g.index.isin(te.loc[lit, "DATE_TIME"].unique()), "p"].values,
                             cap=cap_plant)
            plant_rows.append(dict(
                plant=plant, model=name, 特征组=extra or "全部特征",
                **{f"电站{k}": round(v, 4) for k, v in pl_all.items()},
                **{f"电站有光{k}": round(v, 4) for k, v in pl_lit.items()}))

            print(f"  {name:<22s} 全时段 MAE={m_all['MAE']:7.2f} RMSE={m_all['RMSE']:7.2f} | "
                  f"有光 MAE={m_lit['MAE']:7.2f} RMSE={m_lit['RMSE']:7.2f} "
                  f"nRMSE={m_lit['nRMSE_%']:5.2f}%"
                  + (f"  [训练 {secs:.1f} s]" if secs is not None else ""))
            return rec, m_lit

        # ---------- 基线（不训练）
        sub("基线模型")
        report("训练集均值(基线)", mean_pred(tr, te), "无需特征")
        report("持续性 t-15min(基线)", persistence_pred(te), "仅历史功率")
        report("晴空物理模型(基线)", clear_sky_pred(te, cap_map), "仅辐照度+组件温度")
        report("线性回归(基线)",
               make_models()["线性回归(基线)"]().fit(
                   tr[FEAT_WX_TIME], tr[TARGET]).predict(te[FEAT_WX_TIME]), "仅气象+时间")

        # ---------- 主模型对比（统一用全部特征）
        sub("机器学习模型对比（特征 = 气象 + 时间 + 历史功率）")
        best = (None, 1e18, None, None, None)
        fitted = {}
        for name, ctor in make_models().items():
            if name == "线性回归(基线)":
                continue
            feats = FEAT_WX_TIME_HIST + ["inv_idx"]
            t0 = time.perf_counter()
            mdl = ctor()
            if name == "多层感知机MLP":
                # 神经网络必须做两件事才能训得起来，否则会发散：
                #   1) 特征标准化（滞后/滚动特征量级达上千，ReLU 极易饱和）；
                #   2) 目标取标幺值 P/单机容量（取值约 0~1.2），条件数更好。
                ptr = (tr[TARGET] / tr["SOURCE_KEY"].map(cap_map)).values
                pva = (va[TARGET] / va["SOURCE_KEY"].map(cap_map)).values
                best_n, best_v = None, 1e18
                for ni in (10, 25, 50, 100):
                    m2 = ctor(max_iter=ni)
                    m2.fit(tr[feats], ptr)
                    v = float(np.mean((m2.predict(va[feats]) - pva) ** 2))
                    print(f"      MLP max_iter={ni:4d}  验证集 MSE={v:.5f}")
                    if v < best_v - 1e-9:
                        best_v, best_n = v, ni
                print(f"      -> 选定 max_iter={best_n}（验证集最优）")
                mdl = ctor(max_iter=best_n)
                mdl.fit(tr[feats], ptr)
                pred = mdl.predict(te[feats]) * te["SOURCE_KEY"].map(cap_map).values
            else:
                mdl.fit(tr[feats], tr[TARGET])
                pred = mdl.predict(te[feats])
            pred = np.clip(pred, 0, None)
            dt = time.perf_counter() - t0
            fitted[name] = (mdl, feats, dt)
            rec, _ = report(name, pred, "全部特征", secs=dt)
            abl_rows.append(dict(plant=plant, model=name, 特征组="全部特征",
                                 训练秒=round(dt, 1),
                                 有光MAE=rec["有光MAE"], 有光RMSE=rec["有光RMSE"],
                                 有光nRMSE=rec["有光nRMSE_%"]))
            if rec["有光nRMSE_%"] < best[1]:
                best = (name, rec["有光nRMSE_%"], pred, mdl, feats)

        print(f"\n  -> 最优模型：{best[0]}（有光时段 nRMSE = {best[1]:.2f}%）")
        pred_store[plant] = dict(
            name=best[0], nrmse=best[1],
            pred=pd.DataFrame({
                "plant": plant, "DATE_TIME": te["DATE_TIME"].values,
                "SOURCE_KEY": te["SOURCE_KEY"].values, "IRR": te["IRR"].values,
                "y_true": te[TARGET].values, "y_pred": best[2],
            }))

        # ---------- 特征组消融（固定用 HistGB，只换特征组）
        sub("特征组消融（固定 梯度提升树(HistGB) 模型）")
        groups = {
            "仅气象+时间": FEAT_WX_TIME,
            "气象+时间+历史": FEAT_WX_TIME_HIST,
            "无同期辐照度(仅历史)": FEAT_NO_IRR_NOW,
        }
        hgb = HistGradientBoostingRegressor(max_iter=400, learning_rate=0.08,
                                            max_leaf_nodes=31, min_samples_leaf=20,
                                            l2_regularization=1.0, random_state=SEED)
        for gname, feats in groups.items():
            ff = feats + ["inv_idx"]
            hgb.fit(tr[ff], tr[TARGET])
            pred = hgb.predict(te[ff])
            lit = te["IRR"].values > LIT
            m = metrics(te[TARGET].values[lit], pred[lit], cap=mean_cap)
            abl_rows.append(dict(plant=plant, model="梯度提升树(HistGB)", 特征组=gname,
                                 训练秒=None, 有光MAE=round(m["MAE"], 4),
                                 有光RMSE=round(m["RMSE"], 4),
                                 有光nRMSE=round(m["nRMSE_%"], 4)))
            print(f"  {gname:<24s} 有光 MAE={m['MAE']:7.2f} RMSE={m['RMSE']:7.2f} "
                  f"nRMSE={m['nRMSE_%']:5.2f}%  (特征数 {len(ff)})")
        print()

    # ================================================================ 汇总
    banner("结果汇总")

    df_main = pd.DataFrame(all_rows)
    save_df(df_main, "metrics_main.csv")

    df_plant = pd.DataFrame(plant_rows)
    save_df(df_plant, "metrics_plant.csv")

    df_abl = pd.DataFrame(abl_rows)
    save_df(df_abl, "feature_ablation.csv")

    pred_df = pd.concat([v["pred"] for v in pred_store.values()], ignore_index=True)
    save_df(pred_df, "predictions.csv")

    sub("电站级精度：基线 vs 树模型 vs 最优模型")
    key_models = ["持续性 t-15min(基线)", "线性回归(基线)", "随机森林",
                  "梯度提升树(HistGB)", "LightGBM", "XGBoost", "多层感知机MLP"]
    for pl_ in PLANTS:
        best_name = pred_store[pl_]["name"]
        names = key_models + ([best_name] if best_name not in key_models else [])
        s = df_plant[(df_plant["plant"] == pl_) & (df_plant["model"].isin(names))]
        print(f"\n-- Plant_{pl_} --")
        print(s[["model", "电站有光MAE", "电站有光RMSE", "电站有光nRMSE_%",
                 "电站有光R2"]].to_string(index=False))

    # ================================================================ 图表
    banner("绘图")

    # 图 6：主对比柱状图
    piv = df_main.pivot_table(index="model", values="有光nRMSE_%", columns="plant")
    piv = piv.reindex([m for m in ["训练集均值(基线)", "持续性 t-15min(基线)", "晴空物理模型(基线)",
                                   "线性回归(基线)", "随机森林", "梯度提升树(HistGB)",
                                   "LightGBM", "XGBoost", "多层感知机MLP"]
                      if m in piv.index])
    fig, ax = plt.subplots(figsize=(11, 5))
    x = np.arange(len(piv))
    w = 0.38
    ax.bar(x - w / 2, piv[1], w, label="Plant_1", color=C_MAIN)
    ax.bar(x + w / 2, piv[2], w, label="Plant_2", color=C_ACC)
    ax.set_xticks(x)
    ax.set_xticklabels(piv.index, rotation=18, ha="right", fontsize=9)
    ax.set_ylabel("有光时段 nRMSE (%)")
    ax.set_title("图 6  各模型预测精度对比（逆变器级，有光时段，nRMSE 归一化至单台逆变器容量）",
                 fontsize=11)
    ax.legend()
    fig.savefig(save("fig06_model_comparison.png"))
    plt.close(fig)

    # 图 7：预测 vs 实测 + 残差
    fig, axes = plt.subplots(2, 2, figsize=(13, 8))
    for col, plant in enumerate(PLANTS):
        pr = pred_store[plant]
        nm = pr["name"]
        d_ = pr["pred"]
        lit = d_["IRR"] > LIT
        ax = axes[0][col]
        ax.scatter(d_.loc[lit, "y_true"], d_.loc[lit, "y_pred"], s=5, alpha=0.3,
                   color=C_MAIN, edgecolors="none")
        lim = float(max(d_["y_true"].max(), d_["y_pred"].max())) * 1.03
        ax.plot([0, lim], [0, lim], color=C_BAD, ls="--", lw=1.2, label="理想对角线 y=x")
        ax.set_xlim(0, lim); ax.set_ylim(0, lim)
        ax.set_xlabel("实测 AC_POWER (kW)"); ax.set_ylabel("预测 AC_POWER (kW)")
        ax.set_title(f"Plant_{plant}：实测 vs 预测（{nm}）", fontsize=10)
        ax.legend(fontsize=8)

        ax = axes[1][col]
        e = (d_.loc[lit, "y_pred"] - d_.loc[lit, "y_true"]).values
        ax.hist(e, bins=80, color=C_MAIN, alpha=0.8)
        ax.axvline(0, color=C_BAD, lw=1.2)
        ax.set_xlabel("预测残差 预测-实测 (kW)"); ax.set_ylabel("频数")
        ax.set_title(f"Plant_{plant}：残差分布（均值 {e.mean():.2f} kW，"
                     f"标准差 {e.std():.2f} kW）", fontsize=10)
    fig.suptitle("图 7  最优模型的预测散点与残差分布（有光时段）", fontsize=13)
    fig.tight_layout()
    fig.savefig(save("fig07_pred_vs_true.png"))
    plt.close(fig)

    # 图 8：误差随时段 / 功率水平 / 天气的分布
    fig, axes = plt.subplots(2, 3, figsize=(16, 8))
    for col, plant in enumerate(PLANTS):
        d_ = pred_store[plant]["pred"]
        d_ = d_.copy()
        d_["err"] = d_["y_pred"] - d_["y_true"]
        d_["abs_err"] = d_["err"].abs()
        d_["hour"] = pd.to_datetime(d_["DATE_TIME"]).dt.hour
        lit = d_["IRR"] > LIT

        ax = axes[0][col]
        g = d_[lit].groupby("hour")["abs_err"].mean()
        ax.bar(g.index, g.values, color=C_MAIN)
        ax.set_xlabel("时刻 (h)"); ax.set_ylabel("平均绝对误差 (kW)")
        ax.set_title(f"Plant_{plant}：误差随时段变化", fontsize=10)
        ax.set_xticks(range(0, 24, 2))

        ax = axes[1][col]
        d_["bin"] = pd.qcut(d_.loc[lit, "y_true"], 10, duplicates="drop")
        g2 = d_[lit].groupby("bin", observed=True)["abs_err"].mean()
        ax.plot(range(len(g2)), g2.values, "o-", color=C_ACC, lw=1.6)
        ax.set_xlabel("实测功率十分位分组")
        ax.set_ylabel("平均绝对误差 (kW)")
        ax.set_title(f"Plant_{plant}：误差随功率水平变化", fontsize=10)
    fig.suptitle("图 8  误差分布：低出力与正午高出力时段是误差集中区", fontsize=13)
    fig.tight_layout()
    fig.savefig(save("fig08_error_pattern.png"))
    plt.close(fig)

    banner("建模完成")

print("done")
