# -*- coding: utf-8 -*-
"""01_eda.py -- 数据读取与基本检查（对应基础要求 1、2）

产出：
  * 控制台数据体检报告  -> results/logs/01_eda.log
  * figures/fig01..fig05 五张基础图表
  * results/data_quality.csv 数据质量问题汇总
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from common import (log, banner, sub, load_inverters, load_plant, inverters_complete,
                    save, save_df, STEP, C_MAIN, C_ACC, C_BAD, C_GOOD, C_MUT, C2)

issues = []

with log("01_eda"):

    # ================================================================ 1
    banner("1. 数据读取与基本检查")

    plants = {}
    for p in (1, 2):
        inv, n_src, info = inverters_complete(p)
        pl = load_plant(p)
        plants[p] = dict(inv=inv, n_src=n_src, info=info, plant=pl)

        sub(f"Plant_{p} 数据概况")
        t0, t1 = pl.index.min(), pl.index.max()
        print(f"逆变器台数            : {n_src}")
        print(f"时间范围              : {t0}  ~  {t1}")
        print(f"理论 15min 点数       : {int((t1 - t0) / STEP) + 1}")
        print(f"实际时间戳数          : {len(pl)}")
        print(f"逆变器全部到齐的时刻  : {info['n_ts'] - info['n_gap']} / {info['n_ts']}"
              f"  (缺口 {info['n_gap']} 点，占 {100 * info['gap_frac']:.1f}%)")

        # 气象缺失 -> 线性插值补齐，并记录条数
        nmiss = int(pl[["T_AMB", "T_MOD", "IRR"]].isna().sum().sum())
        print(f"气象缺失值            : {nmiss} 个单元格 -> 线性插值补齐")
        pl[["T_AMB", "T_MOD", "IRR"]] = pl[["T_AMB", "T_MOD", "IRR"]].interpolate(limit_direction="both")
        print(f"补齐后剩余缺失        : {int(pl[['T_AMB','T_MOD','IRR']].isna().sum().sum())}")

        # 时间连续性
        gaps = pl.index.to_series().diff().dropna()
        ngap = int((gaps != STEP).sum())
        print(f"非 15min 的时间间隔   : {ngap} 处")

        # 夜间 / 白天
        h = pl.index.hour
        night = (h < 6) | (h >= 19)
        day = ~night
        print(f"夜间(19:00-06:00) AC=0 点数 : {int((pl.loc[night,'AC_POWER']==0).sum())} / {int(night.sum())}")
        print(f"白天 AC=0 点数              : {int((pl.loc[day,'AC_POWER']==0).sum())} / {int(day.sum())}")
        print(f"AC_POWER 统计 (电站级)      : mean={pl['AC_POWER'].mean():.1f} kW, "
              f"max={pl['AC_POWER'].max():.1f} kW, std={pl['AC_POWER'].std():.1f} kW")
        print(f"IRR (辐照度) 统计           : mean={pl['IRR'].mean():.3f}, max={pl['IRR'].max():.3f}, "
              f"min={pl['IRR'].min():.3f}   <- 单位 kW/m^2，峰值接近 1.2 符合物理常识")
        print(f"T_AMB (环境温度) 统计       : mean={pl['T_AMB'].mean():.2f}, "
              f"范围 [{pl['T_AMB'].min():.2f}, {pl['T_AMB'].max():.2f}] $^\\circ$C")
        print(f"T_MOD (组件温度) 统计       : mean={pl['T_MOD'].mean():.2f}, "
              f"范围 [{pl['T_MOD'].min():.2f}, {pl['T_MOD'].max():.2f}] $^\\circ$C")

        # AC/DC 比
        m = pl["AC_POWER"] > 100
        ratio = pl.loc[m, "AC_POWER"] / pl.loc[m, "DC_POWER"]
        print(f"AC/DC 比值 (AC>100 的点)    : mean={ratio.mean():.4f}, std={ratio.std():.4f}")

        if p == 1:
            issues.append(dict(plant=p, issue="AC/DC 比值异常",
                               detail=f"AC/DC={ratio.mean():.3f}（正常光伏电站应约 0.95~0.99）",
                               handling="AC_POWER 作为预测目标在训练/测试中口径一致，"
                                        "不影响回归任务；仅在报告中说明数据集质量问题"))
        if p == 2:
            issues.append(dict(plant=p, issue="部分逆变器长期离线",
                               detail=f"{info['n_gap']} 个时刻不足 22 台上报（占 {100*info['gap_frac']:.1f}%），"
                                      f"最大缺口 2020-05-20 22:00 ~ 05-29 15:45",
                               handling="建模在逆变器级进行，缺失逆变器不参与；"
                                        "电站级分析仅使用 22 台全部到齐的时刻"))
        print()

    # ================================================================ 2
    banner("2. 图表")

    # ---- 图 1：典型日 出力 + 辐照度
    sub("图 1 典型日出力曲线与辐照度")
    p1 = plants[1]["plant"]
    p2 = plants[2]["plant"]
    # 选取辐照度较高的一天作为代表日
    irr_daily = p1["IRR"].groupby(p1.index.normalize()).sum()
    day = irr_daily.idxmax()
    day_s = str(day.date())
    print(f"代表日选取：{day_s}（Plant_1 全天累计辐照度最高的一天，{irr_daily.max():.2f} kWh/m^2·15min）")

    fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True)
    for ax, pl, name in [(axes[0], p1, "Plant_1"), (axes[1], p2, "Plant_2")]:
        d = pl.loc[day_s]
        t = d.index.hour + d.index.minute / 60
        ax.plot(t, d["AC_POWER"], lw=2, color=C_MAIN, label="AC_POWER 交流出力")
        ax.plot(t, d["DC_POWER"] / 10, lw=1.2, color=C_MUT, ls="--", label="DC_POWER/10 直流出力(缩放)")
        ax2 = ax.twinx()
        ax2.plot(t, d["IRR"] * 1000, lw=1.6, color=C_ACC, alpha=0.85, label="IRRADIATION 辐照度")
        ax2.set_ylabel("辐照度 W/m$^2$", color=C_ACC)
        ax2.tick_params(axis="y", labelcolor=C_ACC)
        ax2.grid(False)
        ax.set_ylabel("功率 kW")
        ax.set_title(f"{name} 典型日（{day_s}）出力与辐照度", fontsize=12)
        ax.set_xticks(range(0, 25, 2))
        ax.grid(alpha=0.3)
        h1, l1 = ax.get_legend_handles_labels()
        h2, l2 = ax2.get_legend_handles_labels()
        ax.legend(h1 + h2, l1 + l2, loc="upper left", fontsize=8)
    axes[1].set_xlabel("时刻 (h)")
    fig.suptitle("图 1  典型日光伏出力与辐照度（两站对比）", fontsize=13, y=0.99)
    fig.savefig(save("fig01_typical_day.png"))
    plt.close(fig)

    # ---- 图 2：辐照度-功率散点
    sub("图 2 辐照度与功率散点")
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, pl, name in [(axes[0], p1, "Plant_1"), (axes[1], p2, "Plant_2")]:
        m = pl["IRR"] > 0.02
        sc = ax.scatter(pl.loc[m, "IRR"] * 1000, pl.loc[m, "AC_POWER"], s=6, alpha=0.35,
                        color=C_MAIN, edgecolors="none")
        ax.set_xlabel("辐照度 (W/m$^2$)")
        ax.set_ylabel("交流出力 AC_POWER (kW)")
        ax.set_title(f"{name}：辐照度 vs 交流出力", fontsize=11)
        ax.set_xlim(left=0)
        fig.colorbar(sc, ax=ax, label="频数")
    fig.suptitle("图 2  辐照度与交流出力的关系（仅统计有辐照的时段）", fontsize=13)
    fig.savefig(save("fig02_irr_power_scatter.png"))
    plt.close(fig)

    # ---- 图 3：温度分布
    sub("图 3 温度分布")
    fig, axes = plt.subplots(2, 2, figsize=(12, 7))
    for row, (pl, name) in enumerate([(p1, "Plant_1"), (p2, "Plant_2")]):
        for col, (colname, cn) in enumerate([("T_AMB", "环境温度"), ("T_MOD", "组件温度")]):
            ax = axes[row][col]
            ax.hist(pl[colname].dropna(), bins=40, color=C_MAIN if row == 0 else C2, alpha=0.85)
            ax.set_title(f"{name} {cn} {colname} 分布 ($^\\circ$C)", fontsize=11)
            ax.set_xlabel("温度 ($^\\circ$C)")
            ax.set_ylabel("频数")
    fig.suptitle("图 3  环境温度与组件温度的分布", fontsize=13)
    fig.tight_layout()
    fig.savefig(save("fig03_temperature_dist.png"))
    plt.close(fig)

    # ---- 图 4：全周期日内出力分布
    sub("图 4 日内出力包络")
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.8), sharex=True)
    for ax, pl, name in [(axes[0], p1, "Plant_1"), (axes[1], p2, "Plant_2")]:
        h = pl.index.hour + pl.index.minute / 60
        g = pd.DataFrame({"h": h, "ac": pl["AC_POWER"].values})
        st = g.groupby("h")["ac"]
        mean = st.mean()
        ax.fill_between(mean.index, st.min().reindex(mean.index), st.max().reindex(mean.index),
                        color=C_MAIN, alpha=0.18, label="逐日包络 最小~最大")
        ax.plot(mean.index, mean.values, lw=2, color=C_MAIN, label="逐时刻均值")
        ax.plot(mean.index, st.quantile(0.5).reindex(mean.index).values,
                lw=1.2, color=C_ACC, ls="--", label="中位数")
        ax.set_title(f"{name} 全周期（34 天）日内 AC_POWER 分布", fontsize=11)
        ax.set_xlabel("时刻 (h)")
        ax.set_ylabel("功率 kW")
        ax.set_xticks(range(0, 25, 2))
        ax.legend(fontsize=8, loc="upper left")
    fig.suptitle("图 4  日内出力规律：呈明显的单峰钟形，13:00 前后达峰", fontsize=13)
    fig.tight_layout()
    fig.savefig(save("fig04_intraday_envelope.png"))
    plt.close(fig)

    # ---- 图 5：数据缺口可视化
    sub("图 5 数据完整性与数据质量问题")
    fig, axes = plt.subplots(2, 1, figsize=(13, 6.5), sharex=True)
    for ax, p, name in [(axes[0], 1, "Plant_1"), (axes[1], 2, "Plant_2")]:
        pl = plants[p]["plant"]
        n_src = plants[p]["n_src"]
        ax.plot(pl.index, pl["n_src"], lw=1.0, color=C_MAIN)
        ax.axhline(n_src, color=C_BAD, ls="--", lw=1.2, label=f"满额 {n_src} 台")
        ax.set_ylim(0, n_src + 3)
        ax.set_ylabel("上报逆变器台数")
        ax.set_title(f"{name}  每个时刻实际上报的逆变器台数", fontsize=11)
        ax.legend(fontsize=8)
    axes[1].set_xlabel("时间")
    fig.suptitle("图 5  数据完整性检查：Plant_2 在 5-20 之后长期只有 18 台逆变器上报", fontsize=13)
    fig.tight_layout()
    fig.savefig(save("fig05_data_completeness.png"))
    plt.close(fig)

    # ================================================================ 3
    banner("3. 数据质量问题汇总")
    # 夜间零功率占比
    for p in (1, 2):
        pl = plants[p]["plant"]
        h = pl.index.hour
        night = (h < 6) | (h >= 19)
        issues.append(dict(
            plant=p, issue="夜间功率恒为 0",
            detail=f"{int((pl.loc[night,'AC_POWER']==0).sum())} / {int(night.sum())} 个夜间时刻 AC=0，"
                   f"占全样本 {100*night.mean():.1f}%；若全时段平均会掩盖模型真实精度",
            handling="所有指标同时报告『全时段』与『有光时段(IRR>0)』两套结果"))
    # 温度传感器物理越界检查
    for p in (1, 2):
        pl = plants[p]["plant"]
        oob = int((pl["T_AMB"] > 45).sum() + (pl["T_MOD"] > 85).sum())
        # 辐照度日间跳变：相邻 15min 变化超过 0.5 kW/m^2 且两侧都有光
        d = pl["IRR"].diff().abs()
        lit = (pl["IRR"] > 0.02) & (pl["IRR"].shift(1) > 0.02)
        jump = int(((d > 0.5) & lit).sum())
        peak = int((d > 0.8).sum())
        issues.append(dict(
            plant=p, issue="气象传感器物理一致性检查",
            detail=f"温度越界记录 {oob} 条（环境>45$^\\circ$C 或组件>85$^\\circ$C）；"
                   f"有光时段相邻 15min 辐照度跳变>0.5 kW/m$^2$ 的 {jump} 点，"
                   f"其中跳变>0.8 kW/m$^2$ 的 {peak} 点",
            handling=("未发现系统性越界，跳变点与云团遮挡导致的光照快速波动一致，"
                      "予以保留：这类样本正是模型误差的主要来源，剔除会使结论失真")))

    df_iss = pd.DataFrame(issues)
    print(df_iss.to_string(index=False))
    save_df(df_iss, "data_quality.csv")

    banner("EDA 完成")

print("done")
