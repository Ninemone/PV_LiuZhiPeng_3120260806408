# -*- coding: utf-8 -*-
"""02_inspect_raw2.py -- 探查「有光时段功率为零」的记录形态

对应报告 2.3.3 节。诊断用途，不参与主流程。

运行：python 02_inspect_raw2.py
输出：results/logs/02_inspect_raw2.log
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd

from common import log, banner, sub, load_inverters, LIT

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))), "data")

with log("02_inspect_raw2"):
    for plant in (1, 2):
        banner(f"Plant_{plant}  有光时段零读数诊断")
        d = load_inverters(plant, DATA)
        lit = d["IRR"] > LIT

        sub("零读数的规模")
        n_lit = int(lit.sum())
        n_zero = int((lit & (d["AC_POWER"] == 0)).sum())
        print(f"有光样本数            : {n_lit}")
        print(f"其中 AC_POWER 恰为 0  : {n_zero}  ({100 * n_zero / n_lit:.2f}%)")
        hi = d["IRR"] > 0.8
        z_hi = int((hi & (d["AC_POWER"] == 0)).sum())
        print(f"高辐照(>0.8 kW/m^2)样本: {int(hi.sum())}，其中为 0 的 {z_hi} "
              f"({100 * z_hi / int(hi.sum()):.2f}%)")

        sub("判据一：物理上不可能")
        print("   辐照度 > 800 W/m^2 时一台在运逆变器不可能输出恰好 0.0 kW。")
        print("   Plant_2 的这一比例远高于 Plant_1，说明并非普遍现象，而是该站特有的问题。")

        sub("判据二：与辐照度的相关性")
        for k, g in d.groupby("SOURCE_KEY"):
            gl = g[g["IRR"] > LIT]
            corr = gl["AC_POWER"].corr(gl["IRR"])
            zero_pct = 100 * (gl["AC_POWER"] == 0).mean()
            print(f"  逆变器 {k[-6:]}  记录 {len(g):5d}  "
                  f"corr(IRR, AC) = {corr:6.3f}   有光零出力占比 = {zero_pct:5.1f}%")
        cs = d.loc[lit].groupby("SOURCE_KEY").apply(
            lambda g: g["AC_POWER"].corr(g["IRR"]), include_groups=False)
        print(f"  -> 相关系数范围 {cs.min():.3f} ~ {cs.max():.3f}")
        print("     正常的在运逆变器应在 0.93 以上；显著偏低的机组其零读数占比较高。")

        sub("判据三：高辐照时刻的出力呈双峰分布")
        cap = d.groupby("SOURCE_KEY")["AC_POWER"].quantile(0.99)
        hh = d[d["IRR"] > 0.8].copy()
        hh["ratio"] = hh["AC_POWER"] / hh["SOURCE_KEY"].map(cap)
        g = hh.groupby(hh["SOURCE_KEY"].str[-6:])["ratio"].agg(["mean", "std", "count"])
        print(g.sort_values("mean").to_string())
        print("   若为真实出力，各机在相同辐照下的比例应彼此接近、标准差很小；")
        print("   标准差接近 0.4~0.5 说明是「要么满发、要么读数为零」的双峰，不符合物理特性。")

        sub("结论")
        verdict = ("存在系统性记录故障，判定为通信/记录故障，"
                   "在建模时剔除" if n_zero / n_lit > 0.05 else
                   "占比很低，属偶发异常，剔除与否影响有限")
        print(f"   Plant_{plant}: 有光零读数占 {100 * n_zero / n_lit:.2f}%，{verdict}。")
        print(f"   剔除的样本数已由 common.prepare() 统一处理，"
              f"并可通过 03_extension.py 的清洗敏感性分析复核其影响。")
        print()
