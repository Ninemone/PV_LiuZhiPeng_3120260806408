# -*- coding: utf-8 -*-
"""01_inspect_raw.py -- 探查原始 CSV 的真实结构

对应报告 2.3.1 与 2.3.2 节。诊断用途，不参与主流程。

运行：python 01_inspect_raw.py
输出：results/logs/01_inspect_raw.log
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd

from common import log, banner, sub, load_inverters, parse_dt

DATA = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))), "data")

with log("01_inspect_raw"):
    for plant in (1, 2):
        banner(f"Plant_{plant} 原始 CSV 结构")
        gen = pd.read_csv(os.path.join(DATA, f"Plant_{plant}_Generation_Data.csv"),
                          encoding="utf-8")
        wx = pd.read_csv(os.path.join(DATA, f"Plant_{plant}_Weather_Sensor_Data.csv"),
                         encoding="utf-8")

        sub("行数 / 唯一时间戳 / 逆变器台数")
        print(f"发电数据行数        : {len(gen)}")
        print(f"发电数据唯一时间戳  : {gen['DATE_TIME'].nunique()}")
        print(f"逆变器(SOURCE_KEY)数: {gen['SOURCE_KEY'].nunique()}")
        print(f"-> 每行并非电站，而是 1 台逆变器在 1 个时刻的读数；")
        print(f"   同一时间戳会出现 {gen['SOURCE_KEY'].nunique()} 次，必须按时刻聚合才是电站总出力。")
        print(f"气象数据行数        : {len(wx)}  (唯一时间戳 {wx['DATE_TIME'].nunique()})")
        print(f"时间戳范围(发电)    : {gen['DATE_TIME'].min()} ~ {gen['DATE_TIME'].max()}")

        sub("各逆变器的容量（AC_POWER 99 分位）与记录条数")
        cap = gen.groupby("SOURCE_KEY")["AC_POWER"].quantile(0.99)
        cnt = gen.groupby("SOURCE_KEY")["SOURCE_KEY"].size()
        print(f"单机容量范围        : {cap.min():.1f} ~ {cap.max():.1f} kW")
        print(f"22 台合计(Plant 级) : {cap.sum():.0f} kW")
        print(f"各机记录条数范围    : {cnt.min()} ~ {cnt.max()}")
        print(f"   条数偏少的机组即为长期离线机组，"
              f"{'（Plant_2 有 4 台从 05-20 22:00 起停止上报）' if plant == 2 else ''}")

        sub("辐照度量纲核对")
        print(f"IRRADIATION 取值范围: {wx['IRRADIATION'].min():.3f} ~ {wx['IRRADIATION'].max():.3f}")
        print(f"   数据集文档写的是 W/m^2，但峰值仅 {wx['IRRADIATION'].max():.2f}，")
        print(f"   按 W/m^2 理解则传感器全故障；按 kW/m^2 理解峰值约 "
              f"{wx['IRRADIATION'].max()*1000:.0f} W/m^2，")
        print(f"   恰好符合地面太阳总水平辐射量的物理上限，故实际量纲为 kW/m^2。")

        sub("AC/DC 比值核对")
        m = gen["AC_POWER"] > 100
        r = (gen.loc[m, "AC_POWER"] / gen.loc[m, "DC_POWER"])
        print(f"AC/DC = {r.mean():.4f} (std {r.std():.4f})")
        if plant == 1:
            print("   正常光伏电站应在 0.95~0.99，此处约 0.1，属公开数据集的量纲/标注异常。")
            print("   由于 AC_POWER 作为预测目标在训练与测试中口径一致，不影响回归任务本身。")
        else:
            print("   该值正常，说明异常只出现在 Plant_1。")

        sub("时间戳格式")
        print(f"发电文件首行: {open(os.path.join(DATA, f'Plant_{plant}_Generation_Data.csv'), encoding='utf-8').readlines()[1].split(',')[0]}")
        print(f"气象文件首行: {open(os.path.join(DATA, f'Plant_{plant}_Weather_Sensor_Data.csv'), encoding='utf-8').readlines()[1].split(',')[0]}")
        print("   注意 Plant_1 发电文件用 %d-%m-%Y %H:%M，其余三个文件用 ISO 格式。")
        print(f"   统一解析结果: {parse_dt(pd.Series([gen['DATE_TIME'].iloc[0]])).iloc[0]}")
