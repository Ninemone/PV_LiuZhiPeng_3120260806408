# -*- coding: utf-8 -*-
"""03_extension.py -- 拓展项

对应题目 2.4 节：
  拓展 3  天气分场景：按日辐照量把日子分成晴/多云/阴，比较各模型在不同天气下的误差
  拓展 5  可解释性分析：内置重要性 + 置换重要性
  拓展 6  能源应用讨论所需的误差分布（按时段 / 出力水平 / 场景拆解）
  额外    数据清洗敏感性分析：若不做「有光时段零读数」清洗，结论会怎样变化

关于天气分场景的做法
--------------------
按时间顺序留出的测试集只有 8 天，且恰好全是晴天（逐日平均晴空指数 0.97~1.06），
直接在测试集上分场景会导致「阴天」只有几个样本，结论没有说服力。
因此本脚本改用**按日分块的 5 折交叉验证**，为全部 34 天都产生一份
out-of-fold 预测，再按天气场景汇总——这样三个场景都有足够样本量。
模型精度的主结论仍以 02_modeling.py 的时序留出集为准，两者互为补充。

产出
----
results/scenario_errors.csv     分天气场景的误差（5 折 OOF）
results/feature_importance.csv  特征重要性
results/cleaning_sensitivity.csv 清洗敏感性
results/errors_plant*.csv.gz  逐点误差明细
figures/fig09 ~ fig12
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.model_selection import GroupKFold
import lightgbm as lgb

from common import (log, banner, sub, prepare, split_by_day, metrics, save, save_df,
                    FEAT_WX_TIME_HIST, TARGET, LIT,
                    C_MAIN, C_ACC, C_BAD, C_GOOD, C_MUT, C2)

SEED = 42
PLANTS = (1, 2)
N_FOLD = 5

PRETTY = {
    "IRR": "辐照度", "T_AMB": "环境温度", "T_MOD": "组件温度",
    "temp_diff": "组件-环境温差", "temp_ratio": "组件/环境温度比",
    "hour_sin": "时刻正弦编码", "hour_cos": "时刻余弦编码", "irr_sq": "辐照度平方项",
    "ac_lag1": "功率滞后 15min", "ac_lag2": "功率滞后 30min",
    "ac_lag4": "功率滞后 1h", "ac_lag8": "功率滞后 2h", "ac_lag96": "功率滞后 24h",
    "ac_mean1h": "近 1h 功率均值", "ac_std1h": "近 1h 功率标准差",
    "ac_mean4h": "近 4h 功率均值", "ac_max1d": "近 24h 功率最大",
    "ac_min1d": "近 24h 功率最小", "irr_diff1": "辐照度变化率", "inv_idx": "逆变器编号",
}


def lgbm():
    return lgb.LGBMRegressor(n_estimators=600, learning_rate=0.05, num_leaves=63,
                             min_child_samples=20, subsample=0.9, subsample_freq=1,
                             colsample_bytree=0.9, reg_lambda=1.0,
                             random_state=SEED, n_jobs=-1, verbose=-1)


scen_rows, imp_rows, sens_rows, oof_store = [], [], [], {}

with log("03_extension"):

    for plant in PLANTS:
        banner(f"Plant_{plant}")

        d, n_inv, n_bad = prepare(plant, drop_daytime_zero=True)
        feats = FEAT_WX_TIME_HIST + ["inv_idx"]
        d = d.dropna(subset=sorted(set(feats + [TARGET]))).reset_index(drop=True)
        tr, va, te, meta = split_by_day(d)
        cap_map = tr.groupby("SOURCE_KEY")[TARGET].quantile(0.99)
        mean_cap = float(cap_map.mean())
        d["cap"] = d["SOURCE_KEY"].map(cap_map)

        # ============================================================ 天气分场景（拓展 3）
        sub("天气分场景：用全期日累计辐照量做三分位")
        d["day_key"] = d["DATE_TIME"].dt.normalize()
        # IRR 在同一时刻对 22 台逆变器是同一个值，必须先按时刻去重再累加，
        # 否则日辐照量会被放大 22 倍。日累计 = 逐时值(kW/m^2) x 0.25 h -> kWh/m^2
        irr_by_ts = d.groupby("DATE_TIME")["IRR"].first()
        daily_irr = irr_by_ts.groupby(irr_by_ts.index.normalize()).sum() * 0.25
        q1, q2 = daily_irr.quantile([1 / 3, 2 / 3])
        print(f"日累计辐照量 (kWh/m^2): 最小 {daily_irr.min():.2f}, 最大 {daily_irr.max():.2f}, "
              f"33% 分位 {q1:.2f}, 67% 分位 {q2:.2f}")
        print(f"可用于分场景的自然日: {len(daily_irr)} 天 "
              f"（34 天中首日因 lag96 特征预热被剔除）")
        print("  分层: 低辐照日(<%.2f) / 中辐照日 / 高辐照日(>%.2f)" % (q1, q2))

        day_scene = pd.Series("低辐照日", index=daily_irr.index, dtype=object)
        day_scene[daily_irr >= q1] = "中辐照日"
        day_scene[daily_irr >= q2] = "高辐照日"
        d["scene"] = d["day_key"].map(day_scene)

        nday = day_scene.value_counts()
        for s in ("高辐照日", "中辐照日", "低辐照日"):
            print(f"  {s}: {int(nday.get(s, 0))} 天  "
                  f"平均日辐照量 {daily_irr[day_scene == s].mean():.2f} kWh/m^2")
        print("  说明：全期最低日辐照量仍达 %.2f kWh/m^2，而真正阴天通常只有 1~2 kWh/m^2，"
              % daily_irr.min())
        print("        因此本数据集**不含真正的阴天**，上述分层是相对高低而非真正的天气类型。")

        # ============================================================ 5 折按日分块 OOF
        sub(f"{N_FOLD} 折按日分块交叉验证，得到全部样本的 out-of-fold 预测")
        oof = np.full(len(d), np.nan)
        gkf = GroupKFold(n_splits=N_FOLD)
        for k, (fi, fv) in enumerate(gkf.split(d, groups=d["day_key"]), 1):
            m = lgbm()
            m.fit(d.iloc[fi][feats], d.iloc[fi][TARGET])
            oof[fv] = m.predict(d.iloc[fv][feats])
            print(f"  第 {k} 折: 训练 {len(fi)} 条 / 测试 {len(fv)} 条"
                  f"（{d.iloc[fv]['day_key'].nunique()} 天）")
        assert np.isfinite(oof).all(), "OOF 预测存在缺失"
        d["y_pred_oof"] = oof
        d["err_oof"] = d["y_pred_oof"] - d[TARGET]
        d["abs_err_oof"] = d["err_oof"].abs()
        # 持续性基线（同一口径，便于按场景比较）
        d["y_pred_pers"] = d["ac_lag1"]
        d["abs_err_pers"] = (d["ac_lag1"] - d[TARGET]).abs()
        # 晴空参考出力：单机容量 x 同期辐照度，用于构造与功率水平无关的归一化指标
        d["p_ref"] = d["cap"] * d["IRR"]
        oof_store[plant] = d[["DATE_TIME", "SOURCE_KEY", "IRR", "T_AMB", "T_MOD",
                              "day_key", "scene", "cap", "p_ref", TARGET, "y_pred_oof",
                              "err_oof", "abs_err_oof", "abs_err_pers"]].copy()

        lit = d["IRR"] > LIT
        sub("分层误差 I：按日辐照量高低（全期，有光时段）")
        print("nRMSE% 按单机额定容量归一化；nRMSE_ref% 按「单机容量 x 同期辐照度」归一化，")
        print("后者剔除了功率高低的影响，纯粹反映可预测性的好坏。")
        print(f"{'分层':<10s}{'天数':>4s}{'样本':>7s}{'MAE':>8s}{'RMSE':>8s}"
              f"{'nRMSE%':>8s}{'nRMSE_ref%':>12s}{'持续性_ref%':>13s}")
        for s in ("高辐照日", "中辐照日", "低辐照日"):
            m = lit & (d["scene"] == s)
            n = int(m.sum())
            if n == 0:
                continue
            met = metrics(d.loc[m, TARGET], d.loc[m, "y_pred_oof"], cap=mean_cap)
            ref = float(d.loc[m, "p_ref"].mean())
            nref = met["RMSE"] / ref * 100
            bas = metrics(d.loc[m, TARGET], d.loc[m, "y_pred_pers"], cap=mean_cap)
            nref_b = bas["RMSE"] / ref * 100
            nd = int(d.loc[m, "day_key"].nunique())
            print(f"{s:<10s}{nd:>4d}{n:>7d}{met['MAE']:>8.2f}{met['RMSE']:>8.2f}"
                  f"{met['nRMSE_%']:>8.2f}{nref:>12.2f}{nref_b:>13.2f}")
            scen_rows.append(dict(
                plant=plant, 分层方式="日辐照量", 场景=s, 天数=nd, 样本数=n,
                占比=round(100 * n / lit.sum(), 2),
                日均辐照量=round(float(daily_irr[day_scene == s].mean()), 3),
                **{k: round(v, 4) for k, v in met.items()},
                晴空参考出力=round(ref, 2),
                nRMSE_ref=round(nref, 4),
                持续性nRMSE_ref=round(nref_b, 4)))
        met_all = metrics(d.loc[lit, TARGET], d.loc[lit, "y_pred_oof"], cap=mean_cap)
        print(f"{'合计':<10s}{len(daily_irr):>4d}{int(lit.sum()):>7d}{met_all['MAE']:>8.2f}"
              f"{met_all['RMSE']:>8.2f}{met_all['nRMSE_%']:>8.2f}")

        # ---------------- 逐时晴空指数分层：这里才是真正的云遮挡信号
        sub("分层误差 II：按逐时晴空指数 Kc = 实测出力 /(单机容量 x 同期辐照度)")
        d["kc"] = (d[TARGET] / d["p_ref"].clip(lower=1.0)).clip(0, 1.5)
        bins = [0, 0.75, 0.9, 1.0, 1.1, 1.5]
        names = ["Kc<0.75 重遮挡", "0.75~0.9 轻遮挡", "0.9~1.0 接近晴空",
                 "1.0~1.1 晴空", "Kc>1.1 高于晴空"]
        d["kcbin"] = pd.cut(d["kc"], bins=bins, labels=names)
        print(f"{'分层':<16s}{'样本':>7s}{'MAE':>8s}{'RMSE':>8s}"
              f"{'nRMSE_ref%':>12s}{'持续性_ref%':>13s}")
        for s in names:
            m = lit & (d["kcbin"] == s)
            n = int(m.sum())
            if n == 0:
                continue
            met = metrics(d.loc[m, TARGET], d.loc[m, "y_pred_oof"], cap=mean_cap)
            ref = float(d.loc[m, "p_ref"].mean())
            bas = metrics(d.loc[m, TARGET], d.loc[m, "y_pred_pers"], cap=mean_cap)
            print(f"{s:<16s}{n:>7d}{met['MAE']:>8.2f}{met['RMSE']:>8.2f}"
                  f"{met['RMSE'] / ref * 100:>12.2f}{bas['RMSE'] / ref * 100:>13.2f}")
            scen_rows.append(dict(
                plant=plant, 分层方式="逐时晴空指数", 场景=s, 天数=None, 样本数=n,
                占比=round(100 * n / lit.sum(), 2), 日均辐照量=np.nan,
                **{k: round(v, 4) for k, v in met.items()},
                晴空参考出力=round(ref, 2),
                nRMSE_ref=round(met["RMSE"] / ref * 100, 4),
                持续性nRMSE_ref=round(bas["RMSE"] / ref * 100, 4)))

        # ============================================================ 出力水平分组
        sub("误差随出力水平的变化（时序留出测试集）")
        t2 = te.copy()
        t2["y_pred"] = lgbm().fit(tr[feats], tr[TARGET]).predict(t2[feats])
        t2["abs_err"] = (t2["y_pred"] - t2[TARGET]).abs()
        tl = t2["IRR"] > LIT
        t2["pbin"] = pd.qcut(t2.loc[tl, TARGET], 5, labels=False, duplicates="drop").astype(float)
        for b, gsub in t2[tl].groupby("pbin"):
            met = metrics(gsub[TARGET], gsub["y_pred"], cap=mean_cap)
            print(f"  出力档位 {int(b)+1}/5  区间 [{gsub[TARGET].min():7.1f}, "
                  f"{gsub[TARGET].max():7.1f}] kW  n={len(gsub):5d}  "
                  f"MAE={met['MAE']:6.2f}  nRMSE={met['nRMSE_%']:5.2f}%")
            scen_rows.append(dict(plant=plant, 分层方式="出力水平",
                                  场景=f"出力档{int(b)+1}", 天数=None,
                                  样本数=len(gsub), 占比=np.nan, 日均辐照量=np.nan,
                                  **{k: round(v, 4) for k, v in met.items()},
                                  晴空参考出力=np.nan, nRMSE_ref=np.nan,
                                  持续性nRMSE_ref=np.nan))

        # 逐时误差
        t2["hour"] = t2["DATE_TIME"].dt.hour
        hh = t2[tl].groupby("hour")["abs_err"].agg(["mean", "count"])
        sub("误差随时段变化（测试集）")
        print("  " + "  ".join(f"{h:02d}h={v:.0f}" for h, v in hh["mean"].items()))

        # ============================================================ 特征重要性（拓展 5）
        sub("拓展 5  特征重要性（随机森林，内置 + 置换）")
        rf = RandomForestRegressor(n_estimators=300, min_samples_leaf=2,
                                   n_jobs=-1, random_state=SEED)
        rf.fit(tr[feats], tr[TARGET])
        pi = permutation_importance(rf, te[feats], te[TARGET], n_repeats=8,
                                    random_state=SEED, scoring="neg_mean_absolute_error",
                                    n_jobs=-1)
        order = np.argsort(pi.importances_mean)[::-1]
        print(f"{'特征':<18s}{'内置重要性':>12s}{'置换重要性(kW)':>16s}{'标准差':>10s}")
        for i in order:
            imp_rows.append(dict(
                plant=plant, 特征=feats[i], 中文名=PRETTY.get(feats[i], feats[i]),
                内置重要性=round(float(rf.feature_importances_[i]), 6),
                置换重要性=round(float(pi.importances_mean[i]), 4),
                置换标准差=round(float(pi.importances_std[i]), 4)))
            print(f"{PRETTY.get(feats[i], feats[i]):<18s}{rf.feature_importances_[i]:>12.5f}"
                  f"{pi.importances_mean[i]:>16.3f}{pi.importances_std[i]:>10.3f}")

        # ============================================================ 清洗敏感性
        sub("数据清洗敏感性分析")
        d2, _, n_bad2 = prepare(plant, drop_daytime_zero=False)
        d2 = d2.dropna(subset=sorted(set(feats + [TARGET]))).reset_index(drop=True)
        tr2, va2, te2, _ = split_by_day(d2)
        p2 = lgbm().fit(tr2[feats], tr2[TARGET]).predict(te2[feats])
        mc2 = float(tr2.groupby("SOURCE_KEY")[TARGET].quantile(0.99).mean())
        l2 = te2["IRR"] > LIT
        m_raw = metrics(te2.loc[l2, TARGET], p2[l2], cap=mc2)
        m_cln = metrics(t2.loc[tl, TARGET], t2.loc[tl, "y_pred"], cap=mean_cap)
        print(f"  未清洗（保留 {n_bad2} 条有光零读数）: 有光 MAE={m_raw['MAE']:7.2f} "
              f"RMSE={m_raw['RMSE']:7.2f} nRMSE={m_raw['nRMSE_%']:5.2f}%")
        print(f"  已清洗（剔除 {n_bad} 条）           : 有光 MAE={m_cln['MAE']:7.2f} "
              f"RMSE={m_cln['RMSE']:7.2f} nRMSE={m_cln['nRMSE_%']:5.2f}%")
        print(f"  -> 不清洗会让 nRMSE 偏高 "
              f"{m_raw['nRMSE_%'] - m_cln['nRMSE_%']:+.2f} 个百分点")
        for tag, nb_, m_ in (("未清洗", n_bad2, m_raw), ("已清洗", n_bad, m_cln)):
            sens_rows.append(dict(plant=plant, 情形=tag, 有光零读数条数=nb_,
                                  有光MAE=round(m_["MAE"], 4),
                                  有光RMSE=round(m_["RMSE"], 4),
                                  有光nRMSE=round(m_["nRMSE_%"], 4)))
        # 逐点明细有 6 万多行，压缩存储以免仓库过大
        oof_store[plant].to_csv(f"../results/errors_plant{plant}.csv.gz", index=False,
                                encoding="utf-8-sig", compression="gzip")
        print(f"  -> results/errors_plant{plant}.csv.gz")
        print()

    # ================================================================ 汇总
    banner("结果汇总")
    save_df(pd.DataFrame(scen_rows), "scenario_errors.csv")
    save_df(pd.DataFrame(imp_rows), "feature_importance.csv")
    save_df(pd.DataFrame(sens_rows), "cleaning_sensitivity.csv")

    # ================================================================ 绘图
    banner("绘图")
    df_s = pd.DataFrame(scen_rows)
    df_i = pd.DataFrame(imp_rows)
    df_n = pd.DataFrame(sens_rows)
    o1, o2 = oof_store[1], oof_store[2]

    # 图 9：按晴空指数分层的误差
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 5.0))
    kc_names = ["Kc<0.75 重遮挡", "0.75~0.9 轻遮挡", "0.9~1.0 接近晴空",
                "1.0~1.1 晴空", "Kc>1.1 高于晴空"]
    for ax, plant in zip(axes, PLANTS):
        s = df_s[(df_s["plant"] == plant) &
                 (df_s["分层方式"] == "逐时晴空指数")].set_index("场景").reindex(kc_names)
        s = s.dropna(subset=["nRMSE_ref"])
        x = np.arange(len(s))
        ax.bar(x - 0.2, s["nRMSE_ref"], 0.38, label="LightGBM（本文模型）", color=C_MAIN)
        ax.bar(x + 0.2, s["持续性nRMSE_ref"], 0.38, label="持续性基线 t-15min", color=C_MUT)
        for xi, (a, b) in enumerate(zip(s["nRMSE_ref"], s["持续性nRMSE_ref"])):
            ax.text(xi - 0.2, a + 0.6, f"{a:.1f}", ha="center", fontsize=8.5)
            ax.text(xi + 0.2, b + 0.6, f"{b:.1f}", ha="center", fontsize=8.5)
        ax.set_xticks(x)
        ax.set_xticklabels([f"{i}\nn={int(r.样本数)}"
                            for i, r in zip(s.index, s.itertuples())], fontsize=8)
        ax.set_ylabel("按晴空参考出力归一化的 RMSE (%)")
        ax.set_title(f"Plant_{plant}：误差随晴空指数（云遮挡程度）变化\n"
                     f"(全期 5 折 OOF，有光时段)", fontsize=10)
        ax.legend(fontsize=8)
    fig.suptitle("图 9  分层误差：晴空指数越低（云遮挡越强），模型误差急剧上升，"
                 "相对持续性基线的优势也随之缩小", fontsize=12.5)
    fig.tight_layout()
    fig.savefig(save("fig09_scenario_error.png"))
    plt.close(fig)

    # 图 10：特征重要性
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.4))
    for ax, plant in zip(axes, PLANTS):
        t = df_i[df_i["plant"] == plant].nlargest(10, "置换重要性").iloc[::-1]
        ax.barh(t["中文名"], t["置换重要性"], xerr=t["置换标准差"],
                color=C_MAIN, alpha=0.88, capsize=2)
        ax.set_xlabel("置换重要性（打乱该特征后 MAE 的恶化量, kW）")
        ax.set_title(f"Plant_{plant}：随机森林置换重要性 Top 10", fontsize=11)
    fig.suptitle("图 10  特征重要性：辐照度主导，温度与逆变器编号影响很小", fontsize=13)
    fig.tight_layout()
    fig.savefig(save("fig10_feature_importance.png"))
    plt.close(fig)

    # 图 11：误差与晴空指数 / 辐照度的关系
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 4.8))
    for ax, d, name in [(axes[0], o1, "Plant_1"), (axes[1], o2, "Plant_2")]:
        s = d[d["IRR"] > LIT].copy()
        # 用训练期标定的晴空出力作为参考，计算逐时晴空指数
        s["pc_ref"] = s["cap"] * s["IRR"]
        s["kc"] = (s[TARGET] / s["pc_ref"].clip(lower=1.0)).clip(0, 1.5)
        s["kcb"] = pd.cut(s["kc"], [0, 0.6, 0.8, 0.95, 1.05, 1.15, 1.5])
        g = s.groupby("kcb", observed=True)["abs_err_oof"].agg(["mean", "count"])
        ax.plot(range(len(g)), g["mean"], "o-", color=C_BAD, lw=1.8, label="模型 MAE")
        ax2 = ax.twinx()
        ax2.bar(range(len(g)), g["count"], color=C_MUT, alpha=0.3, width=0.55)
        ax2.set_ylabel("样本数", color="#777")
        ax.set_xticks(range(len(g)))
        ax.set_xticklabels([str(i) for i in g.index], fontsize=8)
        ax.set_xlabel("晴空指数 Kc = 实测出力 / (单机容量 x 辐照度)")
        ax.set_ylabel("平均绝对误差 (kW)")
        ax.set_title(f"{name}：误差随晴空指数变化", fontsize=10)
        ax.legend(fontsize=8)
    fig.suptitle("图 11  误差集中在低晴空指数（云遮挡导致出力骤降）的时段", fontsize=13)
    fig.tight_layout()
    fig.savefig(save("fig11_kc_error.png"))
    plt.close(fig)

    # 图 12：清洗敏感性
    fig, ax = plt.subplots(figsize=(7.8, 4.5))
    x = np.arange(len(df_n))
    cols = [C_BAD if r.情形 == "未清洗" else C_GOOD for r in df_n.itertuples()]
    ax.bar(x, df_n["有光nRMSE"], color=cols, width=0.5)
    for xi, v in zip(x, df_n["有光nRMSE"]):
        ax.text(xi, v + 0.15, f"{v:.2f}%", ha="center", fontsize=9)
    ax.set_xticks(x)
    ax.set_xticklabels([f"Plant_{r.plant}\n{r.情形}\n(零读数 {int(r.有光零读数条数)} 条)"
                        for r in df_n.itertuples()], fontsize=9)
    ax.set_ylabel("有光时段 nRMSE (%)")
    ax.set_title("图 12  数据清洗敏感性：剔除「有光时段零读数」对精度的影响", fontsize=11)
    fig.tight_layout()
    fig.savefig(save("fig12_cleaning_sensitivity.png"))
    plt.close(fig)

    banner("拓展项完成")

print("done")
