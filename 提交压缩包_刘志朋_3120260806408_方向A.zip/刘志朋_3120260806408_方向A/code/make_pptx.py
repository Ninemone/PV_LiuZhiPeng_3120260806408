# -*- coding: utf-8 -*-
"""生成答辩幻灯片 PPTX（9 页正文 + 2 页备用），配时 9 分 15 秒。"""
import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
FIG = os.path.join(ROOT, "figures")
OUT = os.path.join(ROOT, "提交材料", "答辩幻灯片_刘志朋_3120260806408.pptx")

C_DARK = RGBColor(0x1A, 0x1A, 0x1A)
C_BLUE = RGBColor(0x1F, 0x5C, 0x99)
C_RED = RGBColor(0xC0, 0x39, 0x2B)
C_GREY = RGBColor(0x66, 0x66, 0x66)
C_BG = RGBColor(0xFF, 0xFF, 0xFF)

prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
BLANK = prs.slide_layouts[6]

NOTES = {
1: """【15 秒 · 开场白，照着念】
老师好，我的方向是光伏功率预测。我会用三分钟讲我发现了什么数据问题，
一分钟讲怎么保证结果可信，两分钟讲效果，最后说不足。
（自我介绍：电气与电子信息学院 2026 级电气 4 班，刘志朋）

⚠ 开口前先看一眼时间。如果是第一个上场，直接开始；不是也没关系。""",

2: """【45 秒】
三个问题，逐条念，不要展开：
1 精度上限 —— 已知当日辐照度、温度和过去的出力，能预测到多准？
2 模型增益 —— 比「直接用上一个时刻的功率」好多少？
3 失效边界 —— 什么情况下会预测不准？

然后指着红框说这一句：
「第三个问题最容易被忽略，但对调度最有用。一个晴天很准、云一来就崩的模型，
工程价值是有限的。所以本文把三分之一的篇幅放在模型什么时候会失效，
而不是堆更复杂的算法。」

【若被追问三个问题怎么来的】
说：1 和 2 是常规的，3 是我做误差分析之后才意识到必须回答的。""",

3: """【1 分 45 秒 · ★最重要的一页 · 如果只记住一页就是这页】
先报数据规模：Kaggle 公开数据集，印度两座电站，22 台逆变器，34 天，15 分钟粒度。

然后三个坑，一个一个讲，节奏要稳：

坑一：每一行不是电站，是一台逆变器。
  同一时间戳在文件里出现 22 次。直接读 AC_POWER 列拿到的是一台的功率，
  峰值 1 400 kW，不是电站总出力 29 000 kW —— 差约 21 倍。
  → 所以先按时刻加总，并且在逆变器级建模。

坑二：辐照度单位是 kW/m²，不是文档写的 W/m²。
  实测最大只有 1.22。我按物理上限反推：地面太阳总辐射最大约 1 000 W/m²，
  1.22 kW/m² = 1 220 W/m²，正好合理；如果真是 W/m² 就差了近一千倍。
  → 物理反推确认，不做单位换算。

坑三：Plant_2 有 11.28% 的「白天功率恰好为 0」，是坏数据。
  辐照度超过 800 W/m² 时，一台在运逆变器不可能输出恰好 0.0 kW。
  而且这些点跟辐照度几乎不相关，相关系数只有 0.27，正常机组应该在 0.93 以上。
  强光时各机出力呈「要么满发、要么为 0」的双峰分布。
  Plant_1 同样条件下只有 0.22%。
  → 判定为通信/记录故障，剔除。

最后补一句（不要省）：
「Plant_2 还有 4 台逆变器 5 月 20 日后掉线。因为我在逆变器级建模，
掉线的机组自然不产生样本，不需要插补。」

【被追问「你怎么确定是故障不是限电」】
如实说：光看这个数据集判断不出来是通信中断还是真实限电，
实际要结合 SCADA 告警日志。这是我报告里写明的不足之一。
判据是物理上不可能 + 相关性异常，两条都摆出来。""",

4: """【1 分 15 秒】
先给定义：数据泄露 = 训练时不小心把答案混进输入，导致测试分数虚高、上线就崩。
然后三层防护，每层两三句：

第一，按日期顺序划分，绝不随机打乱。
  光伏出力相邻时刻高度相似。随机划分的话，某个样本的「下 15 分钟」可能进训练集、
  「上 15 分钟」进测试集 —— 模型等于间接看到了答案。
  我按 60/15/25 分成训练/验证/测试，按天切。

第二，所有用到历史出力的特征，先滞后再滚动。
  「最近 1 小时平均功率」很自然，但直接算的话窗口里就包含了当前时刻，
  而当前时刻的功率正是我要预测的答案。必须先 shift(1) 往前挪一格。

第三，归一化用的容量只从训练集估计。

然后讲绿框，这是加分点：
「这条防护我亲手破坏过一次 —— 把 shift(1) 去掉，误差立刻变成假的 0.0x%，
一眼就能看出是泄露。亲眼见过失效的样子，才真的记住了这条规则。」

最后一句带过指标：
「指标除题目要求的 MAE、RMSE 外，我另加 nRMSE 归一化，
并且有光时段和全时段分开报 —— 因为夜间约 45% 的时刻功率恒为 0，
算进平均会把误差稀释掉，看不出真实水平。」

⚠ 这页容易讲超时。如果第 6 页开始时已过 6 分钟，
后面跳过第 8 页，直接进第 9 页。""",

5: """【45 秒 · 快讲，不要逐行念表】
任何模型打不过基线，就说明白做了。
持续性是实际调度里最常用的朴素做法，所以它是最有意义的对手。

只强调一行：晴空物理模型，额定 × 辐照度 × 温度修正，零可调参数，做到 4.78%。
然后埋伏笔：
「这个模型没有任何可调参数，只凭物理公式就做到 4.78%，比持续性好 2.5 倍。
这说明辐照度才是关键信息 —— 后面特征重要性会印证这一点。」

【若时间紧，这页可以只说一句话】
「我做了四个基线，最重要的是持续性 11.78% 和零参数的晴空物理模型 4.78%。
后者说明辐照度是关键信息。」""",

6: """【1 分 30 秒 · 结果页 · 数字要准】
这是全场的核心数字页。念表要快，重点讲三个结论：

1 比持续性基线好 70.6%（Plant_1）和 41.4%（Plant_2）。
  这是回答研究问题 2 的核心数字。

2 但主要增益来自「用上辐照度」，不是算法本身。
  零参数的物理模型已经 4.78%，梯度提升树只再提升 1.2 个百分点；
  线性回归 3.91% 和随机森林 3.99% 几乎没差别。
  → 物理直觉比复杂算法更值钱。

3 Plant_2 明显更难（8.34% vs 3.58%），因为云更多、数据质量更差。

最后 3 秒补一句：
「我也试了多层感知机，比树模型差。对这种表格型数据，树模型更合适。」

【被追问「3.58% 是不是太好了/能不能上电网」】
直接说：
「3.58% 是在本数据集上的结果，而且用的是同一时刻的实测辐照度，
实际调度拿不到这个数。去掉同期辐照度后，误差升到 5.06%。
而且测试期只有 8 天、全期 34 天，文献建议至少一年，所以这个数字是上限估计。」""",

7: """【1 分 30 秒 · ★第二个亮点 · 评委最可能追问的一页】
先解释 Kc：晴空指数 = 实测出力 ÷（额定容量 × 辐照度），接近 1 表示天气好，
接近 0 表示云挡着。

念两个数字就够：
「晴空条件下 5.76%，重遮挡条件下 44.12%，误差放大 7.7 倍。」

然后重点讲第二个反直觉发现 —— 这是全场最能体现思考深度的地方：
「更反直觉的是：重遮挡时，持续性基线反而不比模型差，
Plant_2 上是 46.88% 对 51.99%，模型反而更差。」

被问到一定要有解释（照念）：
「云团快速移动的时候，『15 分钟前的出力』比『此刻的辐照度』更能反映阵列
当前真实的受光情况。因为辐照度传感器是单点测量，而光伏阵列面积极大，
空间代表性不一致 —— 传感器那儿没云，不代表整个电站没云。
所以结论是：只靠辐照度的模型，在快速天气变化时会失效。」

【如主动提及诚实边界，可省】
「还要说一个诚实的问题：这个数据集 34 天里最低日辐照量还有 2.66 kWh/m²，
而真阴天只有 1 到 2，也就是说数据集里根本没有真正的阴天。
重遮挡样本只占 0.4%，极端天气下的表现我无法验证。」
（如果时间紧，这句留给第 9 页讲）""",

8: """【30 秒 · ★超时第一个跳过的页】
为什么要做这个分析，先说清楚动机：
「不展示的话，评委会怀疑我删数据是为了刷分。」

核心数字一句话：
「Plant_1 的坏数据只占 0.22%，却让误差涨了 1.38 个百分点。
说明少量极端异常值的影响远超其数量占比。」

然后把透明性三件事快速过一遍：物理判据、敏感性分析、诊断脚本可当场翻。

【如果时间紧到只剩 20 秒】
只说：「Plant_2 不清洗是 10.77%，清洗后 8.34%。
我把不清洗的结果也报出来了，判据和诊断脚本都在代码里，可以当场翻。」""",

9: """【1 分钟 · 收尾 · 语速可以稍慢】
不足，按顺序讲四点，不要省第 2 点：

1 数据集里根本没有真正的阴天。34 天日辐照量最低还有 2.66 kWh/m²，
  重遮挡样本只占 0.4%，极端天气下的表现无法从本数据集验证。
  文献建议测试集至少长达一年，本文只有 34 天，
  所以 3.58% 只能视为本数据集上的上限估计。

2 没做 LSTM 等时序深度学习，34 天只有 3 000 个时刻，对时序深度学习太短。
  ⚠ 这里必须如实说：LSTM 我没有保留代码，今天无法演示。
  我实际跑的是前馈神经网络，它没有胜过树模型。

3 没做跨电站迁移验证。对「新建电站没有历史数据」是很实际的场景，值得补。

4 Plant_2 的坏数据只做了剔除没有修复，3 798 条坏读数背后是通信中断还是真实限电，
  光看数据集判断不出来。

个人收获，挑两条讲具体的：
「学会了先怀疑数据、再怀疑模型。我最初 Plant_2 的误差是 22.9%，
  查下来是数据里 11% 的零读数在干扰，不是模型不行。」
「理解了防数据泄露是实验设计的核心，不是写完代码再检查一遍。」

最后：谢谢老师，请批评指正。""",

10: """【备用页 · 不主动讲，被问到特征重要性再翻】
怎么衡量重要性：把某个特征打乱，看模型误差恶化多少。恶化越多越重要。

结果：
- 辐照度 + 辐照度平方项 ≈ 310 kW 的恶化量
- 其余所有特征加起来不到 8 kW
- 温度、逆变器编号都小于 0.3 kW

说明模型基本只靠辐照度预测，和物理吻合。

特征消融（固定梯度提升树，只换特征）：
- 仅气象 + 时间：3.69% / 10.49%
- 气象 + 时间 + 历史功率：3.58% / 8.44%
- 去掉同期辐照度：5.06% / 9.25%

要讲边界条件：
「实际调度拿不到此刻的真实辐照度，只有天气预报。去掉同期辐照度后误差上升
1.5 和 0.8 个百分点 —— 15 分钟超短期调度够用，
次日预测必须显式引入天气预报辐照度。」""",

11: """【备用页 · 被追问「误差到底怎么分布」再翻】
误差不是均匀分布，而是高度集中在 Kc 偏低（云遮挡导致出力骤降）的时段。

结论一句话：
「模型的薄弱环节不是『数值算不准』，而是『云来时突变跟不上』。」

补充机理：
Kc 由实测辐照度计算，而云层移动速度远快于本站气象传感器的采样间隔，
模型实际上是在用已经过时的信息推测当前时刻的云影。""",
}


def add(slide, text, left, top, width, height, size=18, bold=False,
        color=C_DARK, align=PP_ALIGN.LEFT, italic=False, spacing=1.15):
    box = slide.shapes.add_textbox(Inches(left), Inches(top), Inches(width), Inches(height))
    tf = box.text_frame
    tf.word_wrap = True
    for i, ln in enumerate(text.split("\n")):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.text = ln
        p.alignment = align
        p.line_spacing = spacing
        for r in p.runs:
            r.font.size = Pt(size)
            r.font.bold = bold
            r.font.italic = italic
            r.font.color.rgb = color
            r.font.name = "Microsoft YaHei"
    return box


def title_bar(slide, text, sub=None):
    add(slide, text, 0.6, 0.35, 12.2, 0.8, size=32, bold=True, color=C_BLUE)
    bar = slide.shapes.add_shape(1, Inches(0.6), Inches(1.15), Inches(2.2), Inches(0.06))
    bar.fill.solid()
    bar.fill.fore_color.rgb = C_RED
    bar.line.fill.background()
    if sub:
        add(slide, sub, 0.6, 1.28, 12.2, 0.4, size=14, color=C_GREY)


def page_no(slide, n, note=""):
    """页码留在画面上；配时/讲解要点写进备注页（放映时看不到）。"""
    add(slide, str(n), 12.5, 7.0, 0.6, 0.35, size=11, color=C_GREY, align=PP_ALIGN.RIGHT)
    if note:
        slide.notes_slide.notes_text_frame.text = note


def table(slide, data, left, top, width, height, col_w=None, size=14,
          hi_col=None, hi_row=None, head_h=0.34):
    rows, cols = len(data), len(data[0])
    shp = slide.shapes.add_table(rows, cols, Inches(left), Inches(top),
                                 Inches(width), Inches(height))
    tbl = shp.table
    if col_w:
        total = sum(col_w)
        for i, w in enumerate(col_w):
            tbl.columns[i].width = Inches(width * w / total)
    body_h = (height - head_h) / max(rows - 1, 1)
    tbl.rows[0].height = Inches(head_h)
    for r in range(1, rows):
        tbl.rows[r].height = Inches(body_h)
    for r in range(rows):
        for c in range(cols):
            cell = tbl.cell(r, c)
            cell.text = str(data[r][c])
            for p in cell.text_frame.paragraphs:
                p.alignment = PP_ALIGN.CENTER if c > 0 else PP_ALIGN.LEFT
                for run in p.runs:
                    run.font.size = Pt(size)
                    run.font.name = "Microsoft YaHei"
                    if r == 0:
                        run.font.bold = True
                        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                    elif (hi_row is not None and r == hi_row) or (hi_col is not None and c == hi_col):
                        run.font.bold = True
                        run.font.color.rgb = C_RED
            if r == 0:
                cell.fill.solid()
                cell.fill.fore_color.rgb = C_BLUE
            elif hi_row is not None and r == hi_row:
                cell.fill.solid()
                cell.fill.fore_color.rgb = RGBColor(0xFD, 0xED, 0xEC)
            else:
                cell.fill.solid()
                cell.fill.fore_color.rgb = C_BG if r % 2 else RGBColor(0xF4, 0xF6, 0xF8)
    return tbl


# ---------------------------------------------------------------- 1 封面
s = prs.slides.add_slide(BLANK)
add(s, "基于机器学习的光伏功率预测", 0.9, 2.15, 11.5, 1.0, size=40, bold=True, color=C_BLUE)
add(s, "—— 数据质量核查与防泄露建模", 0.9, 3.15, 11.5, 0.7, size=22, color=C_GREY)
ln = s.shapes.add_shape(1, Inches(0.9), Inches(4.05), Inches(3.0), Inches(0.05))
ln.fill.solid(); ln.fill.fore_color.rgb = C_RED; ln.line.fill.background()
add(s, "刘志朋　3120260806408", 0.9, 4.4, 8, 0.5, size=20, bold=True)
add(s, "电气与电子信息学院　2026 级电气 4 班　方向 A", 0.9, 4.95, 9, 0.45, size=16, color=C_GREY)
add(s, "一句话：用 34 天实测数据，把交流出力误差压到额定容量的 3.6%，\n并说明这个数字在什么条件下才成立。",
    0.9, 5.75, 11.5, 0.9, size=15, color=C_BLUE)
page_no(s, 1, NOTES[1])

# ---------------------------------------------------------------- 2 研究问题
s = prs.slides.add_slide(BLANK)
title_bar(s, "研究问题", "三个问题，第三个最容易被忽略、但对调度最有用")
add(s, "1　精度上限", 0.8, 1.95, 3.6, 0.45, size=22, bold=True, color=C_BLUE)
add(s, "已知当日辐照度、温度和过去的出力，\n能预测到多准？", 0.8, 2.45, 3.6, 1.0, size=16)
add(s, "2　模型增益", 4.9, 1.95, 3.6, 0.45, size=22, bold=True, color=C_BLUE)
add(s, "比「直接用上一个时刻的功率」\n这种朴素做法好多少？", 4.9, 2.45, 3.6, 1.0, size=16)
add(s, "3　失效边界", 9.0, 1.95, 3.6, 0.45, size=22, bold=True, color=C_RED)
add(s, "什么情况下会预测不准？", 9.0, 2.45, 3.6, 1.0, size=16)
box = s.shapes.add_shape(1, Inches(0.8), Inches(4.1), Inches(11.8), Inches(1.9))
box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0xFD, 0xED, 0xEC)
box.line.color.rgb = C_RED; box.line.width = Pt(1.2)
add(s, "为什么第 3 个问题最重要", 1.2, 4.35, 5, 0.45, size=19, bold=True, color=C_RED)
add(s, "一个「晴天很准、云一来就崩」的模型，工程价值是有限的。\n"
       "所以本文把 1/3 的篇幅放在「模型什么时候会失效」上，而不是堆更复杂的算法。",
    1.2, 4.85, 11.0, 1.0, size=16)
page_no(s, 2, NOTES[2])

# ---------------------------------------------------------------- 3 数据与三个陷阱
s = prs.slides.add_slide(BLANK)
title_bar(s, "数据与三个陷阱", "本工作的重点：如果评委只记住一页，希望是这一页")
add(s, "Kaggle 公开数据集　印度两座电站　22 台逆变器　34 天　15 分钟粒度", 0.8, 1.85, 11.8, 0.4,
    size=15, color=C_GREY)
table(s, [
    ["陷阱", "现象", "处理"],
    ["① 每行不是电站，\n是一台逆变器",
     "同一时间戳在文件里出现 22 次。直接读 AC_POWER\n拿到单台出力（峰值 1 400 kW），不是电站总出力\n（峰值 29 150 kW）—— 差约 21 倍",
     "先按时刻加总，\n在逆变器级建模"],
    ["② 辐照度单位是\nkW/m²，不是 W/m²",
     "实测最大只有 1.22。按物理上限反推：地面总辐射最大\n约 1 000 W/m²，1.22 kW/m² = 1 220 W/m² 正好合理",
     "物理反推确认，\n不做单位换算"],
    ["③ Plant_2 有 11.28%\n「白天功率恰好为 0」",
     "辐照度 > 800 W/m² 时在运逆变器不可能输出 0.0 kW；\n这些点与辐照度相关系数仅 0.27（正常 > 0.93）",
     "判定为记录故障，剔除。\nPlant_1 同条件仅 0.22%"],
], 0.7, 2.4, 11.9, 4.0, col_w=[2.6, 6.6, 2.9], size=12.5)
page_no(s, 3, NOTES[3])

# ---------------------------------------------------------------- 4 怎么保证可信
s = prs.slides.add_slide(BLANK)
title_bar(s, "怎么保证结果可信", "数据泄露 = 训练时把答案混进输入，导致分数虚高、上线就崩")
add(s, "第一层　按日期顺序划分，绝不随机打乱", 0.8, 1.85, 11.8, 0.4, size=19, bold=True, color=C_BLUE)
add(s, "相邻时刻出力高度相似。随机划分会让「下 15 分钟」进训练集、「上 15 分钟」进测试集，\n"
       "模型等于间接看到答案。我按 60/15/25 分成训练/验证/测试，按天切。",
    0.8, 2.28, 11.8, 0.8, size=15)
add(s, "第二层　所有用到历史出力的特征，先滞后再滚动", 0.8, 3.15, 11.8, 0.4, size=19, bold=True, color=C_BLUE)
add(s, "「最近 1 小时平均功率」很自然，但直接算的话窗口里就包含了当前时刻 —— 而那正是要预测的答案。\n"
       "必须先 shift(1) 往前挪一格，再算 4 步滚动平均。",
    0.8, 3.58, 11.8, 0.8, size=15)
add(s, "第三层　归一化用的容量只从训练集估计", 0.8, 4.45, 11.8, 0.4, size=19, bold=True, color=C_BLUE)
box = s.shapes.add_shape(1, Inches(0.8), Inches(4.95), Inches(11.8), Inches(1.95))
box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0xEF, 0xF6, 0xEC)
box.line.color.rgb = RGBColor(0x4C, 0x8C, 0x4A); box.line.width = Pt(1.2)
add(s, "亲手破坏过一次这条规则", 1.15, 5.12, 6, 0.4, size=17, bold=True, color=RGBColor(0x4C, 0x8C, 0x4A))
add(s, "把 shift(1) 去掉，误差立刻变成假的 0.0x% —— 一眼就看出是泄露。\n"
       "亲眼见过失效的样子，才真正记住了这条规则。\n"
       "指标另加 nRMSE（÷额定功率），有光时段与全时段分开报：夜间约 45% 时刻功率恒为 0，\n"
       "算进平均会把误差稀释掉，看不出真实水平。",
    1.15, 5.55, 11.1, 1.25, size=13, spacing=1.05)
page_no(s, 4, NOTES[4])

# ---------------------------------------------------------------- 5 基线
s = prs.slides.add_slide(BLANK)
title_bar(s, "基线设计", "任何模型打不过基线，就说明白做了")
table(s, [
    ["基线", "做法", "Plant_1 有光 nRMSE"],
    ["训练集均值", "一律预测平均值", "31.77%"],
    ["持续性", "用 15 分钟前的功率（调度最常用）", "11.78%"],
    ["晴空物理模型", "额定 × 辐照度 × 温度修正，零可调参数", "4.78%"],
    ["线性回归", "一条直线拟合", "3.91%"],
], 0.9, 2.0, 11.5, 2.6, col_w=[2.4, 6.1, 3.0], size=15, hi_row=3)
box = s.shapes.add_shape(1, Inches(0.9), Inches(5.0), Inches(11.5), Inches(1.6))
box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0xFD, 0xED, 0xEC)
box.line.color.rgb = C_RED; box.line.width = Pt(1.2)
add(s, "埋一个伏笔（后面会用上）", 1.25, 5.2, 6, 0.4, size=17, bold=True, color=C_RED)
add(s, "晴空物理模型没有任何可调参数，只凭物理公式就做到 4.78%，比持续性好 2.5 倍。\n"
       "这说明辐照度才是关键信息 —— 后面特征重要性会印证这一点。",
    1.25, 5.62, 10.9, 0.9, size=15)
page_no(s, 5, NOTES[5])

# ---------------------------------------------------------------- 6 主要结果
s = prs.slides.add_slide(BLANK)
title_bar(s, "主要结果", "逆变器级建模，按日划分测试期；有光时段 nRMSE（÷ 额定功率）")
if os.path.exists(os.path.join(FIG, "fig06_model_comparison.png")):
    s.shapes.add_picture(os.path.join(FIG, "fig06_model_comparison.png"),
                         Inches(0.55), Inches(1.7), height=Inches(2.75))
table(s, [
    ["模型", "Plant_1", "Plant_2", "训练耗时"],
    ["持续性（基线）", "11.78%", "14.24%", "—"],
    ["晴空物理（基线）", "4.78%", "10.54%", "—"],
    ["线性回归（基线）", "3.91%", "9.81%", "0.1 s"],
    ["随机森林", "3.99%", "8.50%", "3.3 s"],
    ["梯度提升树", "3.58%", "8.44%", "0.8 s"],
    ["LightGBM", "3.58%", "8.34%", "0.9 s"],
], 0.75, 4.5, 6.1, 2.2, col_w=[2.5, 1.3, 1.3, 1.1], size=13, hi_row=6)
add(s, "三个必须讲出来的结论", 7.2, 4.55, 5.4, 0.4, size=18, bold=True, color=C_BLUE)
add(s, "1　比持续性基线好 70.6% / 41.4%\n"
       "2　主要增益来自「用上辐照度」，不是算法本身：\n"
       "　　零参数的物理模型已 4.78%，树模型只再提 1.2 个百分点；\n"
       "　　线性回归与随机森林几乎无差别（3.91% vs 3.99%）\n"
       "　　→ 物理直觉比复杂算法更值钱\n"
       "3　Plant_2 明显更难（8.34% vs 3.58%），云更多、数据更差",
    7.2, 5.0, 5.5, 1.75, size=13.5)
page_no(s, 6, NOTES[6])

# ---------------------------------------------------------------- 7 失效边界
s = prs.slides.add_slide(BLANK)
title_bar(s, "模型什么时候会失效", "按晴空指数 Kc = 实测出力 ÷（额定容量 × 辐照度）分层")
if os.path.exists(os.path.join(FIG, "fig09_scenario_error.png")):
    s.shapes.add_picture(os.path.join(FIG, "fig09_scenario_error.png"),
                         Inches(0.5), Inches(1.75), height=Inches(2.9))
table(s, [
    ["分层", "模型", "持续性基线"],
    ["晴空（Kc 1.0–1.1）", "5.76%", "25.96%"],
    ["接近晴空（0.9–1.0）", "8.45%", "25.51%"],
    ["轻遮挡（0.75–0.9）", "19.29%", "31.47%"],
    ["重遮挡（Kc < 0.75）", "44.12%", "48.78%"],
], 0.75, 4.75, 6.0, 1.95, col_w=[2.8, 1.6, 1.6], size=13, hi_row=4)
add(s, "两个反直觉的发现", 7.1, 4.72, 5.5, 0.35, size=17, bold=True, color=C_RED)
add(s, "1　晴空 5.76% → 重遮挡 44.12%，误差放大 7.7 倍\n\n"
       "2　重遮挡时持续性基线反而不比模型差\n"
       "　　（Plant_2 上 46.88% vs 51.99%，模型更差）\n\n"
       "第 2 点怎么解释（评委最可能追问）：\n"
       "　云团快速移动时，「15 分钟前的出力」比「此刻的辐照度」\n"
       "　更能反映阵列当前受光情况。因为辐照度传感器是单点测量，\n"
       "　而阵列面积极大 —— 传感器那儿没云，不代表整个电站没云。\n"
       "　→ 只靠辐照度的模型，在快速天气变化时会失效。",
    7.1, 5.12, 5.6, 1.75, size=11.5, spacing=1.0)
page_no(s, 7, NOTES[7])

# ---------------------------------------------------------------- 8 清洗敏感性
s = prs.slides.add_slide(BLANK)
title_bar(s, "数据清洗的敏感性", "不展示这个，评委会怀疑我「删数据是为了刷分」")
if os.path.exists(os.path.join(FIG, "fig12_cleaning_sensitivity.png")):
    s.shapes.add_picture(os.path.join(FIG, "fig12_cleaning_sensitivity.png"),
                         Inches(0.6), Inches(1.85), height=Inches(2.9))
table(s, [
    ["电站", "不清洗", "清洗后", "差值"],
    ["Plant_1", "4.96%", "3.58%", "1.38 个百分点"],
    ["Plant_2", "10.77%", "8.34%", "2.43 个百分点"],
], 0.85, 4.95, 6.2, 1.35, col_w=[1.8, 1.4, 1.4, 1.9], size=14)
add(s, "关键点", 7.4, 1.95, 5, 0.4, size=19, bold=True, color=C_RED)
add(s, "Plant_1 的坏数据只占 0.22%，却让误差涨了 1.38 个百分点。\n"
       "→ 少量极端异常值的影响远超其数量占比。",
    7.4, 2.4, 5.2, 1.0, size=15)
add(s, "三件事保证透明", 7.4, 3.55, 5, 0.4, size=19, bold=True, color=C_BLUE)
add(s, "一、给了物理判据（辐照 800 W/m² 时输出 0 不可能）\n"
       "二、做了敏感性分析（不清洗的结果也报出来）\n"
       "三、判据与诊断脚本都在 code/diagnostics/ 里，可当场翻",
    7.4, 4.0, 5.2, 1.2, size=15)
add(s, "工程启示：模型上线后持续监控残差分布，这类传感器故障能被自动发现。",
    7.4, 5.5, 5.2, 0.8, size=14, color=C_GREY, italic=True)
page_no(s, 8, NOTES[8])

# ---------------------------------------------------------------- 9 不足与收获
s = prs.slides.add_slide(BLANK)
title_bar(s, "研究不足与个人收获", "评分表里「研究不足」是加分项，所以主动说")
add(s, "不足（按重要性排序）", 0.8, 1.85, 6, 0.4, size=20, bold=True, color=C_RED)
add(s, "1　数据集里根本没有真正的阴天\n"
       "　　34 天日辐照量最低还有 2.66 kWh/m²（真阴天 1–2），\n"
       "　　重遮挡样本只占 0.4%，极端天气无法验证。\n"
       "　　文献建议测试集至少长达一年，本文只有 34 天 ——\n"
       "　　所以 3.58% 只能视为本数据集上的上限估计。\n\n"
       "2　没做 LSTM 等时序深度学习，34 天对时序深度学习太短。\n"
       "　　注意：LSTM 我没有保留代码，今天无法演示。\n"
       "　　我实际跑的是前馈神经网络，它没胜过树模型。\n\n"
       "3　没做跨电站迁移验证。对「新建电站没有历史数据」\n"
       "　　是很实际的场景，值得补。\n\n"
       "4　Plant_2 的坏数据只剔除未修复：3 798 条坏读数背后是\n"
       "　　通信中断还是真实限电，光看数据集判断不出来。",
    0.8, 2.3, 6.2, 4.4, size=13.5)
add(s, "个人收获", 7.5, 1.85, 5, 0.4, size=20, bold=True, color=C_BLUE)
add(s, "学会了先怀疑数据、再怀疑模型\n"
       "　　最初 Plant_2 误差是 22.9%，查下来是 11% 的\n"
       "　　零读数在干扰，不是模型不行。\n\n"
       "理解了防数据泄露是实验设计的核心\n"
       "　　不是写完代码再检查一遍。我亲手破坏过一次那条规则，\n"
       "　　看到误差变假，才真正记住它。\n\n"
       "第一次知道「指标好看」和「结论可信」是两件事",
    7.5, 2.3, 5.2, 3.2, size=14)
box = s.shapes.add_shape(1, Inches(7.5), Inches(5.6), Inches(5.0), Inches(1.1))
box.fill.solid(); box.fill.fore_color.rgb = RGBColor(0xEF, 0xF6, 0xEC)
box.line.color.rgb = RGBColor(0x4C, 0x8C, 0x4A); box.line.width = Pt(1.2)
add(s, "谢谢老师，请批评指正", 7.85, 5.95, 4.4, 0.5, size=20, bold=True,
    color=RGBColor(0x4C, 0x8C, 0x4A), align=PP_ALIGN.CENTER)
page_no(s, 9, NOTES[9])

# ---------------------------------------------------------------- 备用页
s = prs.slides.add_slide(BLANK)
title_bar(s, "【备用】特征重要性", "不主动讲，被问到再翻")
if os.path.exists(os.path.join(FIG, "fig10_feature_importance.png")):
    s.shapes.add_picture(os.path.join(FIG, "fig10_feature_importance.png"),
                         Inches(0.5), Inches(1.9), width=Inches(6.1))
add(s, "怎么衡量：把某个特征打乱，看误差恶化多少。\n\n"
       "辐照度 + 辐照度平方项 ≈ 310 kW 恶化量\n"
       "其余所有特征加起来不到 8 kW\n"
       "温度、逆变器编号都小于 0.3 kW",
    6.9, 2.0, 5.8, 2.2, size=15)
table(s, [
    ["特征组（固定梯度提升树）", "Plant_1", "Plant_2"],
    ["仅气象 + 时间", "3.69%", "10.49%"],
    ["气象 + 时间 + 历史功率", "3.58%", "8.44%"],
    ["去掉同期辐照度", "5.06%", "9.25%"],
], 6.9, 4.35, 5.8, 1.7, col_w=[3.0, 1.3, 1.3], size=13, hi_row=3)
add(s, "工程结论：实际调度拿不到「此刻」真实辐照度，只有天气预报。\n"
       "去掉同期辐照度后误差升 1.5 / 0.8 个百分点 ——\n"
       "15 分钟超短期调度够用，次日预测必须显式引入天气预报辐照度。",
    0.6, 5.35, 5.9, 1.4, size=13.5, color=C_RED)
page_no(s, 10, NOTES[10])

s = prs.slides.add_slide(BLANK)
title_bar(s, "【备用】误差随晴空指数的连续变化", "不主动讲，被问到再翻")
if os.path.exists(os.path.join(FIG, "fig11_kc_error.png")):
    s.shapes.add_picture(os.path.join(FIG, "fig11_kc_error.png"),
                         Inches(0.7), Inches(1.9), width=Inches(8.0))
add(s, "误差不是均匀分布，\n而是高度集中在 Kc 偏低\n（云遮挡导致出力骤降）的时段。\n\n"
       "→ 模型的薄弱环节不是\n「数值算不准」，\n而是「云来时突变跟不上」。\n\n"
       "Kc 是描述云遮蔽强度的经典指标，\n在光伏预测文献中被广泛使用。",
    9.1, 2.0, 3.6, 3.6, size=14)
page_no(s, 11, NOTES[11])

prs.save(OUT)
print("OK ->", OUT)
print("slides =", len(prs.slides.__iter__.__self__._sldIdLst))





