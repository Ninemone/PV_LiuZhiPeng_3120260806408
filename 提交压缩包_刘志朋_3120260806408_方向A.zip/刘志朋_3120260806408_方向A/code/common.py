# -*- coding: utf-8 -*-
"""common.py -- 公共工具：路径、日志、绘图样式、数据加载与特征工程

数据关键事实（详见 01_eda.py 输出与报告 2.2 节）：

1. 原始发电 CSV 的每一行对应 **一台逆变器（SOURCE_KEY）在一个时刻**的读数，
   每站 22 台，因此单个时间戳会出现 22 次。电站总出力必须按时刻聚合求和。
2. 两站时间戳格式不同：Plant_1 为 ``%d-%m-%Y %H:%M``，Plant_2 为 ``%Y-%m-%d %H:%M:%S``。
3. ``IRRADIATION`` 实际量纲为 kW/m^2（峰值约 1.2），而非数据集文档所写的 W/m^2。
4. Plant_2 有 4 台逆变器在 2020-05-20 21:45 至 05-29 16:15 期间中断上报（约 9 天，之后恢复），电站级直接求和会被
   系统性低估。因此主分析在**逆变器级建模**、电站级只做聚合展示。
"""
import io
import os
import sys
import contextlib

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# ---------------------------------------------------------------- 路径
CODE_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(CODE_DIR)
DATA = os.path.join(ROOT, "data")
FIG = os.path.join(ROOT, "figures")
RES = os.path.join(ROOT, "results")
LOG_DIR = os.path.join(RES, "logs")
for _d in (FIG, RES, LOG_DIR):
    os.makedirs(_d, exist_ok=True)

# ---------------------------------------------------------------- 绘图样式
plt.rcParams.update({
    "font.sans-serif": ["Microsoft YaHei", "SimHei", "DejaVu Sans"],
    "axes.unicode_minus": False,
    "figure.dpi": 120,
    "savefig.bbox": "tight",
    "axes.grid": True,
    "grid.alpha": 0.3,
    "axes.axisbelow": True,
    "legend.framealpha": 0.9,
})

C_MAIN = "#1f77b4"
C_ACC = "#e67e22"
C_GOOD = "#1a9850"
C_BAD = "#d73027"
C_MUT = "#bdbdbd"
C2 = "#6a3d9a"

# ---------------------------------------------------------------- 日志
class _Tee(io.TextIOBase):
    def __init__(self, stream, path):
        self.stream = stream
        self.fh = open(path, "w", encoding="utf-8")

    def write(self, s):
        self.stream.write(s)
        self.fh.write(s)
        return len(s)

    def flush(self):
        self.stream.flush()
        self.fh.flush()

    def isatty(self):
        return False

    def close(self):
        try:
            self.fh.close()
        except Exception:
            pass
        return super().close()


@contextlib.contextmanager
def log(name):
    """把脚本内所有 print 记录到 results/logs/<name>.log（UTF-8）。"""
    path = os.path.join(LOG_DIR, f"{name}.log")
    old = sys.stdout
    sys.stdout = _Tee(old, path)
    try:
        yield
    finally:
        try:
            sys.stdout.close()
        except Exception:
            pass
        sys.stdout = old


def banner(title, ch="="):
    print(f"\n{ch * 78}\n{title}\n{ch * 78}")


def sub(title):
    pad = "-" * max(3, 74 - _wlen(title))
    print(f"\n--- {title} {pad}")


def _wlen(s):
    """按终端宽度估算字符串长度：CJK 字符按 2 计。"""
    return sum(2 if ord(c) > 0x2E80 else 1 for c in s)


def save(name):
    """返回 figures/ 下的绝对路径并打印。"""
    p = os.path.join(FIG, name)
    print(f"  -> figures/{name}")
    return p


def save_df(df, name, index=True):
    """把结果表存到 results/ 并打印。"""
    p = os.path.join(RES, name)
    df.to_csv(p, index=index, encoding="utf-8-sig")
    print(f"  -> results/{name}")
    return p


# ---------------------------------------------------------------- 数据加载
DT_FMT = {1: "%d-%m-%Y %H:%M", 2: "%Y-%m-%d %H:%M:%S"}
STEP = pd.Timedelta("15min")


def parse_dt(s):
    """健壮时间戳解析。

    数据集里只有 ``Plant_1_Generation_Data.csv`` 用 ``%d-%m-%Y %H:%M``，
    其余三个文件都是 ISO 格式。这里先试 dayfirst 格式，失败再退回 ISO，
    避免以后换数据源时又踩格式坑。
    """
    out = pd.to_datetime(s, format="%d-%m-%Y %H:%M", errors="coerce")
    if out.isna().any():
        out = out.fillna(pd.to_datetime(s, errors="coerce", format="mixed"))
    return out

# 原始列名 -> 规范化列名
REN = {
    "DC_POWER": "DC_POWER",
    "AC_POWER": "AC_POWER",
    "DAILY_YIELD": "DAILY_YIELD",
    "AMBIENT_TEMPERATURE": "T_AMB",
    "MODULE_TEMPERATURE": "T_MOD",
    "IRRADIATION": "IRR",          # kW/m^2
}
WX_FMT = DT_FMT  # 保留别名，气象文件除 Plant_1 发电文件外均为 ISO

# 有光时段阈值：辐照度 > 0.02 kW/m^2（约 20 W/m^2），用于区分白天发电时段与夜间
LIT = 0.02


def load_inverters(plant, root=DATA):
    """读取某电站**逆变器级**原始数据（每行 = 1 台逆变器 @ 1 时刻）。

    返回列：DATE_TIME, SOURCE_KEY, DC_POWER, AC_POWER, T_AMB, T_MOD, IRR
    """
    gen = pd.read_csv(os.path.join(root, f"Plant_{plant}_Generation_Data.csv"), encoding="utf-8")
    wx = pd.read_csv(os.path.join(root, f"Plant_{plant}_Weather_Sensor_Data.csv"), encoding="utf-8")
    gen["DATE_TIME"] = parse_dt(gen["DATE_TIME"])
    wx["DATE_TIME"] = parse_dt(wx["DATE_TIME"])
    gen = gen.rename(columns=REN)
    wx = wx.rename(columns=REN)
    wx = wx[["DATE_TIME", "T_AMB", "T_MOD", "IRR"]]
    d = gen.merge(wx, on="DATE_TIME", how="left")
    return d.sort_values(["DATE_TIME", "SOURCE_KEY"]).reset_index(drop=True)


def load_plant(plant, root=DATA):
    """读取某电站**电站级**数据：把 22 台逆变器按时刻聚合，再合并气象。

    同时保留 n_src（该时刻上报的逆变器台数）用于识别数据缺口。
    """
    d = load_inverters(plant, root)
    p = d.groupby("DATE_TIME").agg(
        AC_POWER=("AC_POWER", "sum"),
        DC_POWER=("DC_POWER", "sum"),
        DAILY_YIELD=("DAILY_YIELD", "sum"),
        n_src=("SOURCE_KEY", "nunique"),
        T_AMB=("T_AMB", "first"),
        T_MOD=("T_MOD", "first"),
        IRR=("IRR", "first"),
    )
    return p.sort_index()


def inverters_complete(plant, root=DATA):
    """返回 (df, n_total, gap_info)：仅保留 22 台逆变器全部到齐的时刻。"""
    d = load_inverters(plant, root)
    n_total = d["SOURCE_KEY"].nunique()
    cnt = d.groupby("DATE_TIME")["SOURCE_KEY"].nunique()
    ok = cnt[cnt == n_total].index
    info = {
        "n_total": n_total,
        "n_ts": int(len(cnt)),
        "n_gap": int((cnt < n_total).sum()),
        "gap_frac": float((cnt < n_total).mean()),
    }
    return d[d["DATE_TIME"].isin(ok)].copy(), n_total, info


def prepare(plant, root=DATA, drop_daytime_zero=True):
    """建模用数据准备：逆变器级 + 气象插值补齐 + 损坏读数清洗 + 全部特征。

    数据清洗
    --------
    ``drop_daytime_zero=True`` 时剔除「辐照度 > LIT 但 AC_POWER == 0」的读数。
    判据依据：辐照度超过 800 W/m$^2$ 时一台在运逆变器不可能输出恰好 0.0 kW，
    而 Plant_2 有 11.3% 的有光时段（高辐照时段达 35.2%）读数为 0，
    且这些 0 与辐照度几乎不相关（相关系数低至 0.27），属通信/记录故障而非真实出力。
    Plant_1 同一比例仅 0.22%。详见 results/data_quality.csv 与报告 2.3 节。

    缺失的逆变器不会产生样本行，因此 Plant_2 离线机组自然被排除，不引入偏差。

    返回 (df, n_inv, n_dropped_zero)
    """
    d = load_inverters(plant, root)

    # 气象缺测：先按时间在电站级插值，再广播回各逆变器
    wx = (d.groupby("DATE_TIME")[["T_AMB", "T_MOD", "IRR"]].first()
            .sort_index()
            .interpolate(limit_direction="both")
            .ffill().bfill())
    d = d.drop(columns=["T_AMB", "T_MOD", "IRR"]).merge(
        wx.reset_index(), on="DATE_TIME", how="left")

    d = add_time_features(d)
    d = add_hist_features(d, group="SOURCE_KEY")
    d = add_common_features(d)

    # 逆变器编号（静态属性，不含目标信息）
    keys = sorted(d["SOURCE_KEY"].unique())
    d["inv_idx"] = d["SOURCE_KEY"].map({k: i for i, k in enumerate(keys)})

    n_zero = int(((d["IRR"] > LIT) & (d["AC_POWER"] == 0)).sum())
    if drop_daytime_zero:
        d = d[~((d["IRR"] > LIT) & (d["AC_POWER"] == 0))].copy()
    return d.reset_index(drop=True), len(keys), n_zero


def capacity(df, dates=None):
    """按训练期数据估计各逆变器容量（99 分位有光时段功率），用于 nMAE 归一化。"""
    d = df if dates is None else df[df["date"].isin(dates)]
    return d.groupby("SOURCE_KEY")["AC_POWER"].quantile(0.99)


# ---------------------------------------------------------------- 特征工程
def add_time_features(d):
    """时间特征。仅使用当前时刻已知的日历/太阳位置信息。"""
    d = d.copy()
    t = d["DATE_TIME"]
    d["hour"] = t.dt.hour + t.dt.minute / 60.0
    d["minute_of_day"] = t.dt.hour * 4 + t.dt.minute // 15
    d["date"] = t.dt.normalize()
    d["dayofyear"] = t.dt.dayofyear
    ang = 2.0 * np.pi * d["hour"] / 24.0
    d["hour_sin"] = np.sin(ang)
    d["hour_cos"] = np.cos(ang)
    return d


def add_hist_features(d, group=None):
    """功率类滞后/滚动特征。

    防泄露约定：
      * 所有功率特征一律先 ``shift(1)`` 再滚动，保证窗口内不含当前时刻功率；
      * 默认按整站时间序列计算；传 group（如 SOURCE_KEY 列名）则分组计算。
    """
    d = d.copy()
    for k in (1, 2, 4, 8, 96):
        d[f"ac_lag{k}"] = d.groupby(group)["AC_POWER"].shift(k) if group else d["AC_POWER"].shift(k)
    base = d.groupby(group)["AC_POWER"].shift(1) if group else d["AC_POWER"].shift(1)

    def _roll(ser, w, how, minp):
        if group:
            r = ser.groupby(d[group]).rolling(w, min_periods=minp)
            return getattr(r, how)().reset_index(level=0, drop=True)
        return getattr(ser.rolling(w, min_periods=minp), how)()

    for w, tag in ((4, "1h"), (16, "4h"), (96, "1d")):
        d[f"ac_mean{tag}"] = _roll(base, w, "mean", 1)
        d[f"ac_std{tag}"] = _roll(base, w, "std", 2)
        d[f"ac_max{tag}"] = _roll(base, w, "max", 1)
        d[f"ac_min{tag}"] = _roll(base, w, "min", 1)

    d["irr_diff1"] = d.groupby(group)["IRR"].diff(1) if group else d["IRR"].diff(1)
    return d


def add_common_features(d):
    """气象派生特征。

    注意：题目描述中提到的 TEMP_PERATIO 字段在实际 CSV 中并不存在，
    这里用 T_MOD / T_AMB 自己构造一个等价的组件温升比。
    """
    d = d.copy()
    d["temp_diff"] = d["T_MOD"] - d["T_AMB"]
    d["temp_ratio"] = d["T_MOD"] / d["T_AMB"].replace(0, np.nan)
    d["irr_sq"] = d["IRR"] ** 2
    return d


# 特征分组
F_WX = ["IRR", "T_AMB", "T_MOD", "temp_diff", "temp_ratio"]
F_TIME = ["hour_sin", "hour_cos", "irr_sq"]
F_HIST = ["ac_lag1", "ac_lag2", "ac_lag4", "ac_lag8", "ac_lag96",
          "ac_mean1h", "ac_std1h", "ac_mean4h", "ac_max1d", "ac_min1d", "irr_diff1"]
FEAT_WX_TIME = F_WX + F_TIME                      # 仅气象 + 时间
FEAT_WX_TIME_HIST = F_WX + F_TIME + F_HIST         # 再加历史功率
FEAT_NO_IRR_NOW = ["T_AMB", "T_MOD", "temp_diff", "temp_ratio",
                   "hour_sin", "hour_cos"] + F_HIST   # 无同期辐照度（提前预测）
FEAT_ALL = FEAT_WX_TIME_HIST
TARGET = "AC_POWER"


# ---------------------------------------------------------------- 划分
def split_by_day(d, fracs=(0.60, 0.15, 0.25)):
    """按**日期**顺序划分 train/val/test，绝不随机打乱。

    按天切分可避免同一天的相邻时段跨越训练/测试边界。
    """
    days = np.sort(d["date"].unique())
    n = len(days)
    n_tr = int(round(n * fracs[0]))
    n_va = int(round(n * fracs[1]))
    tr_d = days[:n_tr]
    va_d = days[n_tr:n_tr + n_va]
    te_d = days[n_tr + n_va:]
    tr = d[d["date"].isin(tr_d)]
    va = d[d["date"].isin(va_d)]
    te = d[d["date"].isin(te_d)]
    meta = {
        "n_days": n,
        "train_days": (str(tr_d[0]), str(tr_d[-1])),
        "val_days": (str(va_d[0]), str(va_d[-1])) if len(va_d) else None,
        "test_days": (str(te_d[0]), str(te_d[-1])),
    }
    return tr, va, te, meta


# ---------------------------------------------------------------- 指标
def metrics(y_true, y_pred, cap=None):
    """常用误差指标。cap 为单机额定容量(kW)，用于给出归一化指标 nMAE / nRMSE。

    MAPE 需要注意：夜间目标恒为 0，若直接除以 |y| 会得到无意义的巨大数值。
    这里以 1% 额定容量作为分母下限（光伏预测领域的常见做法）。
    """
    y = np.asarray(y_true, dtype=float)
    p = np.asarray(y_pred, dtype=float)
    m = np.isfinite(y) & np.isfinite(p)
    y, p = y[m], p[m]
    e = y - p
    floor = 0.01 * cap if cap else 1.0
    out = {
        "MAE": float(np.mean(np.abs(e))),
        "RMSE": float(np.sqrt(np.mean(e ** 2))),
        "MAPE_%": float(np.mean(np.abs(e) / np.maximum(np.abs(y), floor)) * 100),
        "R2": float(1 - np.sum(e ** 2) / np.sum((y - y.mean()) ** 2)),
    }
    if cap:
        out["nMAE_%"] = out["MAE"] / cap * 100
        out["nRMSE_%"] = out["RMSE"] / cap * 100
    return out


# ---------------------------------------------------------------- 晴空指数
def clear_sky_index(d, cap):
    """晴空指数 Kc = 实测功率 / 晴空预期功率。

    晴空预期功率用简单的物理模型：额定出力按辐照度线性缩放，再乘组件温度降额
    （组件温度每高于 25 度约损失 0.4%/K），并计入逆变效率。Kc 接近 1 表示晴空。
    """
    g = 1.0 + 0.004 * (d["T_MOD"].fillna(25.0) - 25.0)      # 温度降额
    ref = cap * np.clip(d["IRR"].fillna(0.0), 0, None) / 1.0 * g
    ref = ref.clip(lower=1.0)
    return (d["AC_POWER"].fillna(0.0) / ref).clip(0, 1.5)
