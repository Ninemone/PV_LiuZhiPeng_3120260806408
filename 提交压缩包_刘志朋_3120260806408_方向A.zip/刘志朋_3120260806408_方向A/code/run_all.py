# -*- coding: utf-8 -*-
"""run_all.py -- 一键复现全部结果

用法（在 code/ 目录下）：
    python run_all.py

依次执行数据检查、建模、拓展项三步，
所有控制台输出同时写入 results/logs/，图表写入 figures/，表格写入 results/。
"""
import os
import runpy
import sys
import time

CODE_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(CODE_DIR)

STEPS = [
    ("01_eda.py", "数据读取与基本检查 + 基础图表"),
    ("02_modeling.py", "基线与机器学习模型 + 精度对比"),
    ("03_extension.py", "拓展项：分层误差 / 特征重要性 / 清洗敏感性"),
]

if __name__ == "__main__":
    total = time.perf_counter()
    for i, (script, desc) in enumerate(STEPS, 1):
        print("=" * 78)
        print(f"[{i}/{len(STEPS)}] {script}  ——  {desc}")
        print("=" * 78)
        t0 = time.perf_counter()
        runpy.run_path(script, run_name="__main__")
        print(f"<<< {script} 完成，用时 {time.perf_counter() - t0:.1f} s\n")
    print("=" * 78)
    print(f"全部完成，总用时 {time.perf_counter() - total:.1f} s")
    print("图表 -> figures/    表格 -> results/    运行日志 -> results/logs/")
    print("=" * 78)
